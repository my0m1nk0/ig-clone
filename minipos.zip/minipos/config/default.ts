export default {
  HOST: 'http://localhost',
  PORT: 5000,
  JWT_KEY: 'POS_KEY',
  SMTP_URI: '',
  AWS_ACCESS_KEY: 'AKIATELBVLCPLO25NZ4W',
  AWS_SECRET_KEY: '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',
  S3_BUCKET: 'naing-pos',
  STARTCOUNT: 5,
  DB_URI: "naingpos.cm7sdw7s8kji.ap-southeast-1.rds.amazonaws.com",
  DB_PORT: "5432",
  DB_USER: "nainghtweoo",
  DB_PASS: "nainghtweoo123",
  DB_NAME: "dbpos",
  FIRE_BASE_KEY:'AAAAlbbX6Pw:APA91bFSJNYxrmnK8VgekbEbOlfKS8-PfCh3uax20mJCluzTs73BEl1xjYbYd9KbEErORvAaM4Tx_tFdy6B_iNK3xuwcvTXH_gtliV0VNP_o_nYksR9WaCryBkXDVSJSxRggib9HlP8F'
};
