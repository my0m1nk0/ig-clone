import { Controller, Get, Post, Put, UseGuards, HttpStatus, Body } from '@nestjs/common';
import { AppService } from './app.service';
import { ApiBearerAuth, ApiResponse, ApiOperation, ApiImplicitBody } from '@nestjs/swagger';
import { AuthGuard } from './shared/guard/auth.guard';
import { SuccessMessage } from './shared/filters/success.vm';
import { ApiError } from './shared/api-error.model';
import { getOperation } from './shared/utilities/get-operation';
import { UserD } from './shared/auth/users.decorator';
import { DeviceToken } from './device.dto';
import { async } from 'rxjs/internal/scheduler/async';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Get()
  getHello(): string {
    return this.appService.getHello();
  }

  @Put('device_token')
  @ApiBearerAuth()
  @UseGuards(new AuthGuard())
  @ApiResponse({ status: HttpStatus.OK,type:SuccessMessage})
  @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
  @ApiOperation(getOperation('app', 'update device token'))
  async updateToken(@UserD() user:any,@Body() data:DeviceToken){
    return this.appService.updateDevice(user,data.device_token)
  }

  @Get('checkExpire')
  @ApiBearerAuth()
  @UseGuards(new AuthGuard())
  @ApiResponse({ status: HttpStatus.OK,type:SuccessMessage})
  @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
  @ApiOperation(getOperation('app', 'Check Expire'))
  async checkToken(@UserD() user:any){
    return this.appService.checkUser(user)
  }

}
