import { Controller, Get, UseGuards } from '@nestjs/common';
import {
  ApiOkResponse,
  ApiBadRequestResponse,
  ApiOperation,
  ApiUseTags,
  ApiBearerAuth,
} from '@nestjs/swagger';
import { AuthGuard } from '../shared/guard/auth.guard';
import { ApiError } from '../shared/api-error.model';
import { getOperation } from '../shared/utilities/get-operation';
import { ImagesService } from './images.service';
import { UserD } from '../shared/auth/users.decorator';

@Controller('images')
@ApiUseTags('Images')
export class ImagesController {
  constructor(private readonly _imageService: ImagesService) {}

  @Get('upload')
  @ApiBearerAuth()
  @UseGuards(new AuthGuard())
  @ApiOkResponse({})
  @ApiBadRequestResponse({ type: ApiError })
  @ApiOperation(getOperation('Image', 'GetSignedUrl'))
  imageUpload(@UserD('id') userId: number) {
    return this._imageService.getSignedUrl(`image-${userId}`);
  }

  // @Get('profile')
  // @ApiOkResponse({})
  // @ApiBadRequestResponse({ type: ApiError })
  // @ApiOperation(getOperation('ProfileImage', 'GetProfileSignedUrl'))
  // profileUpload() {
  //   return this._imageService.getSignedUrl();
  // }
}
