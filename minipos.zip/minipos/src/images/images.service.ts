import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { S3 } from 'aws-sdk';
import uuid = require('uuid');
import { ConfigurationService } from '../shared/configuration/configuration.service';
import { Configuration } from '../shared/configuration/configuration.enum';

@Injectable()
export class ImagesService {
  constructor(
    private readonly s3: S3,
    private readonly _configurationService: ConfigurationService,
  ) {}

  async getSignedUrl(userId: string = 'shop') {
    const key = `${userId}/${uuid()}.jpeg`;
    try {
      const url = await this.s3.getSignedUrl('putObject', {
        Bucket: this._configurationService.get(Configuration.S3_BUCKET),
        ContentType: 'image/jpeg',
        Expires: 60 * 60,
        Key: key,
      });

      return { key: key, url: url };
    } catch (e) {
      throw new HttpException(e, HttpStatus.BAD_REQUEST);
    }
  }
}
