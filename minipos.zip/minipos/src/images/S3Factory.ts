import { S3 } from 'aws-sdk';
import { ConfigurationService } from '../shared/configuration/configuration.service';
import { Configuration } from '../shared/configuration/configuration.enum';

let instance: S3;

export const s3Factory = {
  provide: S3.name,
  useFactory: (configService: ConfigurationService) => {
    if (!instance) {
      instance = new S3({
        accessKeyId: configService.get(Configuration.AWS_ACCESS_KEY),
        secretAccessKey: configService.get(Configuration.AWS_SECRET_KEY),
      });
    }
    return instance;
  },
  inject: [ConfigurationService],
};
