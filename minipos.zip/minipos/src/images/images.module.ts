import { Module } from '@nestjs/common';
import { ImagesController } from './images.controller';
import { ImagesService } from './images.service';
import { s3Factory } from './S3Factory';

@Module({
  controllers: [ImagesController],
  providers: [ImagesService, s3Factory],
})
export class ImagesModule {}
