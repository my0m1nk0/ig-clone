import { Entity, Column, BeforeInsert, BeforeUpdate } from "typeorm";
import { BaseModel } from "../../shared/base.model";
import { ApiModelProperty } from "@nestjs/swagger";
import { Configuration } from "../../shared/configuration/configuration.enum";
import { get } from "config"
import { ShiftProgress } from "./shift-progress.enum";
@Entity()
export class UserShift extends BaseModel{
    @ApiModelProperty()
    @Column()
    shop_id:number

    @ApiModelProperty()
    @Column()
    shop_user_id:number

    @ApiModelProperty()
    @Column({type:'bigint'})
    shift_in:number

    @ApiModelProperty()
    @Column({type:'bigint'})
    shift_out:number

    @ApiModelProperty()
    @Column({type:'bigint'})
    shift_date:number

    @ApiModelProperty()
    @Column({enum:ShiftProgress,default:ShiftProgress.UNDONE})
    progress:ShiftProgress

    constructor(partial: Partial<UserShift>) {
        super()
        Object.assign(this, partial);
    }
}