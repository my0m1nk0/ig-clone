export enum ShiftProgress{
    DONE = 'Done',
    UNDONE = 'Undone'
}