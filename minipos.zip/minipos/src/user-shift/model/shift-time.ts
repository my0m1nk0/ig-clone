import { ApiModelProperty } from "@nestjs/swagger"
import { ValidateNested, IsNotEmpty } from "class-validator"
import { DateShitTime } from "./date-shift-tiime"

export class ShiftTime{
    @ApiModelProperty()
    @IsNotEmpty()
    @ValidateNested()
    Sunday:DateShitTime

    @ApiModelProperty()
    @IsNotEmpty()
    @ValidateNested()
    Monday:DateShitTime

    @ApiModelProperty()
    @IsNotEmpty()
    @ValidateNested()
    Tuesday:DateShitTime

    @ApiModelProperty()
    @IsNotEmpty()
    @ValidateNested()
    Wednesday:DateShitTime

    @ApiModelProperty()
    @IsNotEmpty()
    @ValidateNested()
    Thursday:DateShitTime

    @ApiModelProperty()
    @IsNotEmpty()
    @ValidateNested()
    Friday:DateShitTime

    @ApiModelProperty()
    @IsNotEmpty()
    @ValidateNested()
    Saturday:DateShitTime
}


