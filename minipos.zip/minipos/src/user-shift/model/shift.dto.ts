import { ApiModelProperty } from "@nestjs/swagger"
import { IsNotEmpty, ValidateNested } from "class-validator"
import { ShiftTime } from "./shift-time"

export class ShiftDto{
    @ApiModelProperty()
    @IsNotEmpty()
    shop_id?:number

    @ApiModelProperty()
    @IsNotEmpty()
    shop_user_id:number

    @ApiModelProperty()
    @IsNotEmpty()
    shift_from_date:string

    @ApiModelProperty()
    @IsNotEmpty()
    shift_to_date:string
    
    @ApiModelProperty()
    @IsNotEmpty()
    @ValidateNested()
    shift_time:ShiftTime
    
}

