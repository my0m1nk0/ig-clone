import { ApiModelProperty } from "@nestjs/swagger"
import { IsNotEmpty } from "class-validator"

export class DateShitTime{
    @ApiModelProperty()
    @IsNotEmpty()
    first:number

    @ApiModelProperty()
    @IsNotEmpty()
    second:number
}