import { Controller, Post, Body, UsePipes, ValidationPipe, UseGuards, HttpStatus, Get, Query, Delete, Param } from '@nestjs/common';
import { UserShiftService } from './user-shift.service';
import { ShiftDto } from './model/shift.dto';
import { ApiUseTags, ApiBearerAuth, ApiResponse, ApiOperation, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { AuthGuard } from 'src/shared/guard/auth.guard';
import { UserShift } from './model/user-shift.entity';
import { ApiError } from 'src/shared/api-error.model';
import { getOperation } from 'src/shared/utilities/get-operation';
import { ParseIntPipe } from 'src/shared/parse-int.pipe';

const modelName = "UserShift"

@Controller('user-shift')
@ApiUseTags(modelName)
@UsePipes(new ValidationPipe())
@ApiBearerAuth()
@UseGuards(new AuthGuard())
export class UserShiftController {
    constructor(
        private readonly _shiftService:UserShiftService
    ){}

    @Post()
    @ApiResponse({ status: HttpStatus.CREATED,type:UserShift,isArray:true})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Create Shift'))
    async addShift(@Body() data:ShiftDto ){
        return await this._shiftService.addShift(data)
    }

    @Get()
    @ApiResponse({ status: HttpStatus.CREATED,type:UserShift,isArray:true})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Get User Shift'))
    @ApiImplicitQuery({name:'user_id',type:String,required:true})
    @ApiImplicitQuery({name:'shop_id',type:String,required:true})
    @ApiImplicitQuery({name:'from_date',type:String,required:true})
    @ApiImplicitQuery({name:'to_date',type:String,required:true})
    async getShift(
        @Query("user_id",new ParseIntPipe()) user_id:number,
        @Query("shop_id",new ParseIntPipe()) shop_id:number,
        @Query("from_date",new ParseIntPipe()) from_date:number,
        @Query("to_date",new ParseIntPipe()) to_date:number
    ){ 
        return await this._shiftService.getShift(shop_id,user_id,from_date,to_date)
    }

    @Delete('byid/:id')
    @ApiResponse({ status: HttpStatus.CREATED,type:UserShift,isArray:true})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Delete User Shift'))
    @ApiImplicitParam({name:'id',type:String,required:true})
    async deleteShift(@Param('id') id:string){
        return await this._shiftService.deleteShift(id)
    }

    @Delete('byrage/')
    @ApiResponse({ status: HttpStatus.CREATED,type:UserShift,isArray:true})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Delete User Shift'))
    @ApiImplicitQuery({name:'user_id',type:String,required:true})
    @ApiImplicitQuery({name:'from_date',type:String,required:true})
    @ApiImplicitQuery({name:'to_date',type:String,required:true})
    async deleteShiftByRage(
        @Query("from_date",new ParseIntPipe()) from_date:number,
        @Query("user_id",new ParseIntPipe()) user_id:number,
        @Query("to_date",new ParseIntPipe()) to_date:number
    ){
        return await this._shiftService.deleteShiftByRage(to_date,from_date,user_id)
    }


}
