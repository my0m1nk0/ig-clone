import { Injectable, HttpStatus, HttpException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { UserShift } from './model/user-shift.entity';
import { Repository, LessThanOrEqual, Between } from 'typeorm';
import { ShiftDto } from './model/shift.dto';

@Injectable()
export class UserShiftService {
    days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    constructor(
        @InjectRepository(UserShift) private readonly _shift:Repository<UserShift>,
    ){}

    async addShift(data:ShiftDto){
        try{
            let fromDate = new Date(data.shift_from_date).getTime()
            let toDate = new Date(data.shift_to_date).getTime()
            let respose = []
            while(fromDate < toDate){
                let dateName = this.days[new Date(fromDate).getDay()]
                let shiftTime = data.shift_time[dateName]
                if(shiftTime.first > 0 && shiftTime.second > 0){
                    let newShift
                    let shift = await this._shift.findOne({where:{shift_date:fromDate,shop_id:data.shop_id,shop_user_id:data.shop_user_id}})
                    if(shift){
                        shift.shift_in = shiftTime.first
                        shift.shift_out = shiftTime.second
                        newShift = await this._shift.save(shift)
                    }else{
                        let newShi = new UserShift({shift_date:fromDate,shop_id:data.shop_id,shop_user_id:data.shop_user_id,shift_in:shiftTime.first,shift_out:shiftTime.second})
                        newShift = await this._shift.save(newShi)
                    }
                    
                    respose.push(newShift)
                }
                let addDate = new Date(fromDate) 
                fromDate = addDate.setDate(addDate.getDate() + 1)
            }
            return { message:"Success"}
        }catch(e){
            throw new HttpException(e, HttpStatus.INTERNAL_SERVER_ERROR); 
        }
    }

    async getShift(shop_id:number,user_id:number,fromDate:number,toDate:number){
        try {
            let data = await this._shift.find({where:
                {shop_id:shop_id,shop_user_id:user_id,shift_date:Between(fromDate,toDate)}
            })
            return data
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR); 
        }
    }

    async deleteShift(id){
        try {
            let shift = await this._shift.findOne(id)
            this._shift.remove(shift)
            return { message:"Success"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR); 
        }
    }

    async deleteShiftByRage(from:number,to:number,user_id:number){
        try {
            let shifts = await this._shift.find({where:{shift_date:Between(from,to),shop_user_id:user_id}})
            this._shift.remove(shifts)
            return { message:"Success"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR); 
        }
    }

}