import { Module } from '@nestjs/common';
import { UserShiftController } from './user-shift.controller';
import { UserShiftService } from './user-shift.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserShift } from './model/user-shift.entity';

@Module({
  imports:[
    TypeOrmModule.forFeature([UserShift]),
  ],
  controllers: [UserShiftController],
  providers: [UserShiftService]
})
export class UserShiftModule {}
