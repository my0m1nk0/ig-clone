import { Module, UsePipes } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { APP_FILTER } from '@nestjs/core';
import { HttpExceptionFilter } from './shared/filters/http-exception-filter.filter';
import { ValidationPipe } from './shared/validation.pipe';
import { ConfigurationService } from './shared/configuration/configuration.service';
import { Configuration } from './shared/configuration/configuration.enum';
import { TypeOrmModule } from '@nestjs/typeorm'
import { SharedModule } from './shared/shared.module';
import { get } from 'config';
import { AdminModule } from './admin/admin.module';
import { FeatureModule } from './features/feature.module';
import { PackageModule } from './package/package.module';
import { ShopModule } from './shop/shop.module';
import { ShopLicenseModule } from './shop-license/shop-license.module';
import { ShopUserModule } from './shop-user/shop-user.module';
import { StockCategoryModule } from './stock-category/stock-category.module';
import { StockItemModule } from './stock-item/stock-item.module';
import { StockEntryModule } from './stock-entry/stock-entry.module';
import { OrderModule } from './order/order.module';
import { OrderItemModule } from './order-item/order-item.module';
import { ImagesModule } from './images/images.module';
import { UserShiftModule } from './user-shift/user-shift.module';
import { RequestLicenseModule } from './request-license/request-license.module';
import { SendedNotiModule } from './sended-noti/sended-noti.module';
import { PusherNotiModule } from './pusher-noti/pusher-noti.module';
@Module({
  imports: [
    SharedModule,
    TypeOrmModule.forRoot({
    type: "postgres",
    host: ConfigurationService.configString,
    port: parseInt(process.env[Configuration.DB_PORT]) || get(Configuration.DB_PORT),
    username: process.env[Configuration.DB_USER] || get(Configuration.DB_USER),
    password: process.env[Configuration.DB_PASS] || get(Configuration.DB_PASS),
    database: process.env[Configuration.DB_NAME] || get(Configuration.DB_NAME),
    entities: [__dirname + "/**/**/*.entity{.ts,.js}"],
    synchronize: true,
    }),
    AdminModule,
    FeatureModule,
    PackageModule,
    ShopModule,
    ShopLicenseModule,
    ShopUserModule,
    StockCategoryModule,
    StockItemModule,
    StockEntryModule,
    OrderModule,
    OrderItemModule,
    ImagesModule,
    UserShiftModule,
    RequestLicenseModule,
    SendedNotiModule,
    PusherNotiModule
  ],
  controllers: [AppController],
  providers: [
    AppService,
    {
      provide: APP_FILTER,
      useClass: HttpExceptionFilter,
    },
    {
      provide: UsePipes,
      useClass: ValidationPipe,
    },
  ],
})
export class AppModule {
  static host: string;
  static port: number | string;
  static isDev: boolean;

  constructor(private readonly _configServer: ConfigurationService) {
    AppModule.port = AppModule.normalizePort(
      _configServer.get(Configuration.PORT),
    );
    AppModule.host = _configServer.get(Configuration.HOST);
    AppModule.isDev = _configServer.isDevelopment;
  }

  private static normalizePort(param: number | string): number | string {
    const portNumber: number =
      typeof param == 'string' ? parseInt(param, 10) : param;
    if (isNaN(portNumber)) return param;
    else if (portNumber > 0) return portNumber;
  }
}