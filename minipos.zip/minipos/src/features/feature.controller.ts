import { Controller, UsePipes, UseGuards, HttpStatus, Get, Post, Put, Body, Param, Delete } from '@nestjs/common';
import { ValidationPipe } from '../shared/validation.pipe';
import { ApiUseTags, ApiBearerAuth, ApiResponse, ApiOperation, ApiImplicitBody } from '@nestjs/swagger';
import { FeatureService } from './feature.service';
import { AuthGuard } from '../shared/guard/auth.guard';
import { Feature } from './model/feature.entity';
import { getOperation } from '../shared/utilities/get-operation';
import { ApiError } from '../shared/api-error.model';
import { UserD } from '../shared/auth/users.decorator';
import { Role } from '../admin/model/role.enum';
import { SuccessMessage } from '../shared/filters/success.vm';
import { ParseIntPipe } from '../shared/parse-int.pipe';
import { FeatureDto, ChangeAccess } from './model/feature.dto';
import { RoleName } from './model/role-name';
const modelName = 'Features'

@Controller('features')
@ApiUseTags(modelName)
@UsePipes(new ValidationPipe())
@ApiBearerAuth()
@UseGuards(new AuthGuard())
export class FeatureController {
    constructor(private readonly _feature:FeatureService){}

    @Get()
    @ApiResponse({ status: HttpStatus.OK,type:Feature,isArray:true})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Get features'))
    async getAll(@UserD('role') role:Role){
        return await this._feature.getAll(role)
    }

    @Post()
    @ApiResponse({ status: HttpStatus.CREATED,type:SuccessMessage})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Create Feature'))
    async create(@Body() data:FeatureDto){
        return this._feature.createFeature(data)
    }

    @Put(':id')
    @ApiResponse({ status: HttpStatus.OK,type:SuccessMessage})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Update Feature'))
    async update(@Body() data:FeatureDto,@Param('id',new ParseIntPipe()) id:number ){
        return this._feature.updateFeature(data,id)
    }

    @Put('access_role/:id')
    @ApiResponse({ status: HttpStatus.OK,type:SuccessMessage})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Change Feature Access Role'))
    @ApiImplicitBody({name:'ChangeAccess',type:ChangeAccess})
    async updatePassword(@Body('access_role') access_role:RoleName[],@Param('id',new ParseIntPipe()) id:number ){
        return this._feature.changeAccessRole(access_role,id)
    }

    @Delete(':id')
    @ApiResponse({ status: HttpStatus.OK,type:SuccessMessage})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Delete Feature'))
    async delete(@Param('id',new ParseIntPipe()) id:number){
        return this._feature.deleteFeature(id)
    }

}
