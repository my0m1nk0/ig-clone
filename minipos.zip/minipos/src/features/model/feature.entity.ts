import { BaseModel } from "../../shared/base.model";
import { Entity, Column } from "typeorm";
import { ApiModelProperty } from "@nestjs/swagger";
import { AccessRole } from "./access-role";

@Entity()
export class Feature extends BaseModel {
    @ApiModelProperty()
    @Column({type:'varchar'})
    name:string

    @ApiModelProperty()
    @Column({type:'json',default: {role:[]} })
    access_role:AccessRole

}