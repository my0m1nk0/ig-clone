import { Role } from "../../admin/model/role.enum";
import { ApiModelProperty } from "@nestjs/swagger";
import { IsEnum } from "class-validator";

export class RoleName{
    @ApiModelProperty()
    @IsEnum(Role)
    name:Role

    constructor(partial: Partial<RoleName>) {
        Object.assign(this, partial);
    }
}