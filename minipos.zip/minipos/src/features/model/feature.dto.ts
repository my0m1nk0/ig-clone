import { ApiModelProperty, ApiModelPropertyOptional } from "@nestjs/swagger";
import { IsString, IsArray, ValidateNested } from "class-validator";
import { AccessRole } from "./access-role";
import { Role } from "../../admin/model/role.enum";
import { RoleName } from "./role-name";

export class FeatureDto{

    @ApiModelProperty()
    @IsString()
    name:string

    @ApiModelProperty({ type: [RoleName] })
    @ValidateNested()
    access_role:RoleName[] = []

}

export class ChangeAccess{
    @ApiModelProperty({ type: [RoleName] })
    @ValidateNested()
    access_role:RoleName[]
}