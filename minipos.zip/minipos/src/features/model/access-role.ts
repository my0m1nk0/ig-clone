import { RoleName } from "./role-name";

export class AccessRole{
    role:RoleName[]
    constructor(partial: Partial<AccessRole>) {
        Object.assign(this, partial);
    }
}