import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Feature } from './model/feature.entity';
import { Repository, In, Not, Equal, Any } from 'typeorm';
import { FeatureDto } from './model/feature.dto';
import { Role } from '../admin/model/role.enum';
import { AccessRole } from './model/access-role';
import { RoleName } from './model/role-name';

@Injectable()
export class FeatureService {
    constructor(
        @InjectRepository(Feature) private readonly _feature:Repository<Feature>,
        ){
    }

    async getAll(role:Role){
        try {            
            let data = await this._feature.query(`SELECT id,name FROM public.feature ,json_array_elements(access_role->'role') elem where 
            elem->>'name' = '${role}'`);
            return data
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);  
        } 
    }

    async createFeature(data:FeatureDto){
        let feature = await this._feature.find({where:{name:data.name}})
        if(feature.length > 0)
            throw new HttpException("Feature is Already Created!", HttpStatus.BAD_REQUEST);
        try {
            let acc_role = new AccessRole({role:data.access_role})
            let newFeature = new Feature()
            newFeature.name = data.name
            newFeature.access_role = acc_role
            await this._feature.save(newFeature)
            return {"message":"Created New Feature!"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async updateFeature(data:FeatureDto,id:number){
        let features = await this._feature.find({where:{name:data.name,id:Not(Equal(id))}})
        if(features.length > 0)
            throw new HttpException("Feature name is Already Exist!", HttpStatus.BAD_REQUEST);
        try{
            let acc_role = new AccessRole({role:data.access_role})
            let feature = await this._feature.findOne(id)
            feature.name = data.name
            feature.access_role = acc_role  
            await this._feature.save(feature)
            return {"message":"Updated Feature !"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async changeAccessRole(access_role:RoleName[],id:number){
        try{
            let acc_role = new AccessRole({role:access_role})
            let feature = await this._feature.findOne(id)
            feature.access_role = acc_role
            await this._feature.save(feature)
            return {"message":"Updated Feature Access Role!"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async deleteFeature(id:number){
        try{
            let feature =  await this._feature.findOne(id)
            await this._feature.remove(feature)
            return {"message":"Deleted Feature !"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

}
