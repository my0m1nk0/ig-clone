import { Module } from '@nestjs/common';
import { FeatureController } from './feature.controller';
import { FeatureService } from './feature.service';
import { Feature } from './model/feature.entity';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports:[TypeOrmModule.forFeature([Feature])],
  controllers: [FeatureController],
  providers: [FeatureService]
})
export class FeatureModule {}
