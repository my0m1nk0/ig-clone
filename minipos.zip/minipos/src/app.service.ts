import { Injectable, forwardRef, Inject, HttpException, HttpStatus } from '@nestjs/common';
import { ShopUserService } from './shop-user/shop-user.service';
import { AdminService } from './admin/admin.service';
import { ShopLicenseService } from './shop-license/shop-license.service';

@Injectable()
export class AppService {
  constructor(
    @Inject(forwardRef(() => ShopUserService)) readonly _shopUserService: ShopUserService,
    @Inject(forwardRef(() => ShopLicenseService)) readonly _shopLicenseService: ShopLicenseService,
    @Inject(forwardRef(() => AdminService)) readonly _adminService: AdminService,
  ){}
  getHello(): string {
    return 'Hello World!';
  }

  async updateDevice(user:any,device:string){
    try {
      if("admin" == user.role )
        await this._adminService.updateDevice(user.id,device)
      else
        await this._shopUserService.updateDevice(user.id,device)
      return {message:"Success Update Device Token!"}
    } catch (error) {      
      throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR); 
    }
  }

  async checkUser(user){
    try {
      if("admin" != user.role){
        let shopUser = await this._shopUserService.getUser(user.id)
        let expire = await this._shopLicenseService.checkExist(shopUser.shop_id)
        if(expire.length == 0)
          throw new HttpException({message:"Your Shop Is Expired",shop:shopUser.shop_id}, HttpStatus.PAYMENT_REQUIRED); 
      }
    }catch(e){
      throw new HttpException(e, HttpStatus.NOT_ACCEPTABLE);
    }
  }
}
