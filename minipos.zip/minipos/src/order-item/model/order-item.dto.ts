import { ApiModelProperty, ApiModelPropertyOptional } from "@nestjs/swagger"
import { IsNotEmpty } from "class-validator";

export class OrderItemDto{
    // @ApiModelPropertyOptional()
    order_id?:number
    
    @ApiModelProperty()
    @IsNotEmpty()
    category_id:number

    @ApiModelProperty()
    @IsNotEmpty()
    item_id:number

    @ApiModelProperty()
    @IsNotEmpty()
    name:string

    @ApiModelProperty()
    @IsNotEmpty()
    item_code:string

    @ApiModelProperty()
    @IsNotEmpty()
    price:number

    @ApiModelProperty()
    @IsNotEmpty()
    qty:number

    @ApiModelProperty()
    @IsNotEmpty()
    image:string

    constructor(partial: Partial<OrderItemDto>) {
        Object.assign(this, partial);
    }
}