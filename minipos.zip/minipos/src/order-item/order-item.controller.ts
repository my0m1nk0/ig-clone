import { Controller, Get, HttpStatus, UsePipes, UseGuards, Query, ParseIntPipe } from '@nestjs/common';
import { OrderItemService } from './order-item.service';
import { ApiResponse, ApiUseTags, ApiBearerAuth, ApiOperation, ApiImplicitQuery } from '@nestjs/swagger';
import { OrderItem } from './model/order-item.entity';
import { ApiError } from '../shared/api-error.model';
import { ValidationPipe } from '../shared/validation.pipe';
import { AuthGuard } from '../shared/guard/auth.guard';
import { getOperation } from '../shared/utilities/get-operation';

const modelName = "Order Item"

@Controller('order-item')
@ApiUseTags(modelName)
@UsePipes(new ValidationPipe())
@ApiBearerAuth()
@UseGuards(new AuthGuard())
export class OrderItemController {
    constructor(private readonly _orderItemService:OrderItemService){}

    @Get()
    @ApiResponse({ status: HttpStatus.OK,type:OrderItem,isArray:true})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Get Order Item'))
    @ApiImplicitQuery({name:'skip',type:Number,required:true})
    @ApiImplicitQuery({name:'limit',type:Number,required:false})
    @ApiImplicitQuery({name:'order_id',type:Number,required:true})
    async getAll(
        @Query('skip',new ParseIntPipe()) skip:number,
        @Query('limit') limit:string=null,
        @Query('order_id',new ParseIntPipe()) order_id:number
        ){
        return await this._orderItemService.getAll(order_id,skip,limit)
    }
}
