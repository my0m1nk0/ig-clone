import { Injectable, HttpException, HttpStatus, Inject, forwardRef } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { OrderItem } from './model/order-item.entity';
import { Repository } from 'typeorm';
import { OrderItemDto } from './model/order-item.dto';
import { StockItemService } from '../stock-item/stock-item.service';
import { EntryType } from '../stock-entry/model/entry-type.enum';

@Injectable()
export class OrderItemService {
    constructor(
        @InjectRepository(OrderItem) private readonly _orderItem:Repository<OrderItem>,
        @Inject(forwardRef(() => StockItemService)) readonly _stockItemService: StockItemService,
        ){
    }
    async getAll(order_id:number,skip:number,limit:string){
        try {
            let takeLimit = parseInt(limit) > 0 ? {take:parseInt(limit)} : {}
            let data = await this._orderItem.find({where:{order_id:order_id},skip:skip,...takeLimit,order:{id:-1}})
            return data
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);  
        } 
    }

    async createItem(data:OrderItemDto){
       try {
            let newOrderItem = new OrderItem(data)
            await this._orderItem.save(newOrderItem)
            await this._stockItemService.entryStock(newOrderItem.item_id,newOrderItem.qty,EntryType.MINUS)
            return {"message":"Created New Order Item!"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    // async deleteItem(id:number){
    //     try{
    //         let item =  await this._orderItem.findOne(id)
    //         await this._orderItem.remove(item)
    //         return {"message":"Deleted Item !"}
    //     } catch (error) {
    //         throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
    //     }
    // }
  
}
