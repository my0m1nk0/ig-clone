import { Module, forwardRef } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Item } from './model/item.entity';
import { StockItemService } from './stock-item.service';
import { StockItemController } from './stock-item.controller';
import { ShopLicenseModule } from 'src/shop-license/shop-license.module';

@Module({
    imports:[
        TypeOrmModule.forFeature([Item]),
        forwardRef(() => ShopLicenseModule),
    ],
    providers: [StockItemService],
    controllers: [StockItemController],
    exports:[StockItemService]
})
export class StockItemModule {}
