import { ApiModelProperty, ApiModelPropertyOptional } from "@nestjs/swagger";
import { IsNotEmpty } from "class-validator";

export class ItemDto {
    
    shop_id?:number

    category_id?:number

    @ApiModelProperty()
    @IsNotEmpty()
    name:string

    @ApiModelProperty()
    @IsNotEmpty()
    item_code:string

    @ApiModelProperty()
    @IsNotEmpty()
    selling_price:number

    @ApiModelPropertyOptional()
    // @IsNotEmpty()
    image?:string
    
}