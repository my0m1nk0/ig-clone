import { Entity, Column, BeforeInsert, BeforeUpdate } from "typeorm";
import { BaseModel } from "../../shared/base.model";
import { ApiModelProperty } from "@nestjs/swagger";
import { Configuration } from "../../shared/configuration/configuration.enum";
import { get } from "config"
@Entity()
export class Item extends BaseModel{
    @ApiModelProperty()
    @Column()
    shop_id:number

    @ApiModelProperty()
    @Column()
    category_id:number

    @ApiModelProperty()
    @Column()
    name:string

    @ApiModelProperty()
    @Column({unique:true})
    item_code:string

    @ApiModelProperty()
    @Column()
    selling_price:number

    @ApiModelProperty()
    @Column({default:0})
    qty:number

    @ApiModelProperty()
    @Column({nullable:true})
    image?:string

    @ApiModelProperty()
    @Column({nullable:true,type:'text'})
    image_url?:string

    @BeforeInsert()
    updateInesrtData() {
        let s3b = process.env.S3_BUCKET || get(Configuration.S3_BUCKET);
        const img = this.image || 'no-images.png';
        this.image_url =  `https://naing-pos.s3-ap-southeast-1.amazonaws.com/${img}`
    }

    @BeforeUpdate()
    updateData() {
        let s3b = process.env.S3_BUCKET || get(Configuration.S3_BUCKET);
        const img = this.image || 'no-images.png';
        this.image_url =  `https://naing-pos.s3-ap-southeast-1.amazonaws.com/${img}`
    }
    
    constructor(partial: Partial<Item>) {
        super()
        Object.assign(this, partial);
    }
}