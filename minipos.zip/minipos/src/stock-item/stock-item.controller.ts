import { Controller, UsePipes, UseGuards, Get, HttpStatus, Param, ParseIntPipe, Query, Post, Body, Put, Delete } from '@nestjs/common';
import { ApiUseTags, ApiBearerAuth, ApiResponse, ApiOperation, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { ValidationPipe } from '../shared/validation.pipe';
import { AuthGuard } from '../shared/guard/auth.guard';
import { StockItemService } from './stock-item.service';
import { Item } from './model/item.entity';
import { ApiError } from '../shared/api-error.model';
import { getOperation } from '../shared/utilities/get-operation';
import { SuccessMessage } from '../shared/filters/success.vm';
import { ItemDto } from './model/item.dto';
const modelName = "Stock Item"

@Controller('shop/:shop_id/stock-item')
@ApiUseTags(modelName)
@UsePipes(new ValidationPipe())
@ApiBearerAuth()
@UseGuards(new AuthGuard())
export class StockItemController {
    constructor(private readonly _itemService:StockItemService){}

    @Get()
    @ApiResponse({ status: HttpStatus.OK,type:Item,isArray:true})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Get Item'))
    @ApiImplicitQuery({name:'skip',type:Number,required:true})
    @ApiImplicitQuery({name:'limit',type:Number,required:true})
    @ApiImplicitParam({name:'shop_id',type:Number,required:true})
    @ApiImplicitQuery({name:'category_id',type:Number,required:true})
    async getAll(
        @Param('shop_id',new ParseIntPipe()) shop_id:number,
        @Query('skip',new ParseIntPipe()) skip:number,
        @Query('limit') limit:string=null,
        @Query('category_id',new ParseIntPipe()) category_id:number
        ){
        return await this._itemService.getAll(shop_id,category_id,skip,limit)
    }

    @Get('filter')
    @ApiResponse({ status: HttpStatus.OK,type:Item,isArray:true})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Get Item By name Filter'))
    @ApiImplicitQuery({name:'name',type:String,required:true})
    @ApiImplicitParam({name:'shop_id',type:Number,required:true})
    async findItem(
        @Param('shop_id',new ParseIntPipe()) shop_id:number,
        @Query('name') name: string
        ){
        return await this._itemService.findItem(shop_id,name)
    }

    @Post()
    @ApiResponse({ status: HttpStatus.CREATED,type:Item})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Create Item'))
    @ApiImplicitParam({name:'shop_id',type:Number,required:true})
    @ApiImplicitQuery({name:'category_id',type:Number,required:true})
    async create(
        @Body() data:ItemDto,
        @Param('shop_id',new ParseIntPipe()) shop_id:number,
        @Query('category_id',new ParseIntPipe()) category_id:number
        ){
        data.shop_id = shop_id
        data.category_id = category_id
        return this._itemService.createItem(data)
    }

    @Put(':id')
    @ApiResponse({ status: HttpStatus.OK,type:Item})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Update Item'))
    async update(
        @Body() data:ItemDto,
        @Param('id',new ParseIntPipe()) id:number,
        ){
        return this._itemService.updateItem(data,id)
    }

    @Delete(':id')
    @ApiResponse({ status: HttpStatus.OK,type:SuccessMessage})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Delete Item'))
    async delete(@Param('id',new ParseIntPipe()) id:number){
        return this._itemService.deleteItem(id)
    }
}
