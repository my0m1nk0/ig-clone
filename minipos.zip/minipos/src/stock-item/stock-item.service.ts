import { Injectable, HttpException, HttpStatus, Inject, forwardRef } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Item } from './model/item.entity';
import { Repository, Not, Equal, Like } from 'typeorm';
import { ItemDto } from './model/item.dto';
import { EntryType } from '../stock-entry/model/entry-type.enum';
import { ShopLicenseService } from 'src/shop-license/shop-license.service';

@Injectable()
export class StockItemService {
    constructor(
        @InjectRepository(Item) private readonly _item:Repository<Item>,
        @Inject(forwardRef(() => ShopLicenseService)) readonly _shopLicenseService: ShopLicenseService,
        ){
    }
    async getAll(shop:number,category_id:number,skip:number,limit:string){
        try {
            let takeLimit = parseInt(limit) > 0 ? {take:parseInt(limit)} : {} 
            let data = await this._item.find({where:{shop_id:shop,category_id:category_id},skip:skip,...takeLimit,order:{id:-1}})
            return data
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);  
        } 
    }

    async getCount(query:any){
       return await this._item.count(query)
    }

    async findItem(shop:number,name){
        try {
            let data = await this._item.find({where:[{shop_id:shop, item_code: Like(`${name}%`)},{shop_id:shop, name: Like(`${name}%`)}],order:{id:-1},take:5})
            return data
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);  
        }
    }

    async createItem(data:ItemDto){
        let items = await this.checkExist(data.name,data.shop_id)
        if(items.length > 0)
            throw new HttpException("Item Code is Already Created!", HttpStatus.BAD_REQUEST);
        let itemCount = await this._item.count({shop_id:data.shop_id})
        let shopLicense = await this._shopLicenseService.checkExpire(data.shop_id)
        if(shopLicense[0].no_of_stock <= itemCount )
            throw new HttpException("You have reach your package limitation !", HttpStatus.BAD_REQUEST);
        try {
            let newItem = new Item(data)
            return await this._item.save(newItem)
            return {"message":"Created New Item!"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async updateItem(data:ItemDto,id:number){
        let items = await this.checkExist(data.name,data.shop_id,id)
        if(items.length > 0)
            throw new HttpException("Item code is Already Exist!", HttpStatus.BAD_REQUEST);
        try{
            let item = await this._item.findOne(id)
            item.name = data.name
            item.item_code = data.item_code
            item.selling_price = data.selling_price
            item.image = data.image
            return await this._item.save(item)
            return {"message":"Updated Item !"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async checkExist(name:string,shop:number,id:number=0){
        let filter = { name,shop}
        return await this._item.find({where:{...filter,id:Not(Equal(id))}})
    }

  
    async deleteItem(id:number){
        try{
            let item =  await this._item.findOne(id)
            await this._item.remove(item)
            return {"message":"Deleted Item !"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }
    async entryStock(item_id:number,no_of_stock:any,type:EntryType){
        let item =  await this._item.findOne(item_id)
        if(type == EntryType.MINUS){
            if(item.qty < no_of_stock)
                throw new HttpException("Not Enought Stock Quantity", HttpStatus.BAD_REQUEST);  
        }
        try{
            item.qty = type == EntryType.ADD ? item.qty + parseInt(no_of_stock) : item.qty - no_of_stock
            return await this._item.save(item)
            // return {"message":"Deleted Item !"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }
}
