import { ApiModelProperty } from "@nestjs/swagger";
import { IsNotEmpty } from "class-validator";

export class DeviceToken{
    @ApiModelProperty()
    @IsNotEmpty()
    device_token:string
}