import { Entity, Column, BeforeInsert, BeforeUpdate } from "typeorm";
import { BaseModel } from "../../shared/base.model";
import { ApiModelProperty } from "@nestjs/swagger";
@Entity()
export class Orders extends BaseModel{

    @ApiModelProperty()
    @Column({type:'bigint',default:new Date().getTime()})
    voucher_id:number

    @ApiModelProperty()
    @Column()
    shop_id:number

    @ApiModelProperty()
    @Column()
    account_id:number

    @ApiModelProperty()
    @Column()
    amount:string

    @ApiModelProperty()
    @Column()
    net_total:string

    @ApiModelProperty()
    @Column({default:0})
    discount:number

    @ApiModelProperty()
    @Column({default:0})
    tax:number

    @ApiModelProperty()
    @Column({default:0})
    service_charges:number

    @ApiModelProperty()
    @Column({type:'bigint',default:0})
    order_date:number

    @ApiModelProperty()
    @Column({default:0})
    total_qty:number

    @ApiModelProperty()
    @Column({nullable:true})
    change:number

    @ApiModelProperty()
    @Column({nullable:true})
    pay_amount:number

    constructor(partial: Partial<Orders>) {
        super()
        Object.assign(this, partial);
    }
}