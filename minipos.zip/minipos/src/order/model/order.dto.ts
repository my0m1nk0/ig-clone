import { ApiModelPropertyOptional, ApiModelProperty } from "@nestjs/swagger"
import { OrderItemDto } from "../../order-item/model/order-item.dto"
import { ValidateNested, IsNotEmpty } from "class-validator"

export class OrderDto{

    shop_id?:number

    account_id:number

    @ApiModelProperty()
    amount:string

    @ApiModelProperty()
    net_total:string

    @ApiModelPropertyOptional()
    discount?:number

    @ApiModelPropertyOptional()
    tax?:number

    @ApiModelPropertyOptional()
    service_charges?:number

    @ApiModelPropertyOptional()
    @IsNotEmpty()
    order_date:number

    @ApiModelPropertyOptional()
    @IsNotEmpty()
    total_qty:number

    @ApiModelProperty({type:[OrderItemDto]})
    @ValidateNested()
    order_item_list:OrderItemDto[]

    @ApiModelPropertyOptional()
    change?:number

    @ApiModelPropertyOptional()
    pay_amount?:number
}