import { Controller, ValidationPipe, UsePipes, UseGuards, Post, HttpStatus, Body, Get, ParseIntPipe, Query } from '@nestjs/common';
import { ApiUseTags, ApiBearerAuth, ApiResponse, ApiOperation, ApiImplicitQuery } from '@nestjs/swagger';
import { AuthGuard } from '../shared/guard/auth.guard';
import { getOperation } from 'src/shared/utilities/get-operation';
import { OrderService } from './order.service';
import { OrderDto } from './model/order.dto';
import { Orders } from './model/order.entity';
import { ApiError } from 'src/shared/api-error.model';
import { UserD } from 'src/shared/auth/users.decorator';

const modelName = "Order"

@Controller('order')
@ApiUseTags(modelName)
@UsePipes(new ValidationPipe())
@ApiBearerAuth()
@UseGuards(new AuthGuard())
export class OrderController {
    constructor(private readonly _orderService:OrderService){}

    @Get()
    @ApiResponse({ status: HttpStatus.OK,type:Orders,isArray:true})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Get Order'))
    @ApiImplicitQuery({name:'skip',type:Number,required:true})
    @ApiImplicitQuery({name:'limit',type:Number,required:true})
    @ApiImplicitQuery({name:'shop_id',type:Number,required:true})
    @ApiImplicitQuery({name:'account_id',type:Number,required:false})
    @ApiImplicitQuery({name:'from_date',type:Number,required:false})
    @ApiImplicitQuery({name:'to_date',type:Number,required:false})
    async getAll(
        @Query('skip',new ParseIntPipe()) skip:number,
        @Query('limit') limit:string=null,
        @Query('shop_id',new ParseIntPipe()) shop_id:number,
        @Query('account_id') account_id:string=null,
        @Query('from_date') from_date:string=null,
        @Query('to_date') to_date:string=null
        ){
        return await this._orderService.getAll(shop_id,skip,parseInt(limit),parseInt(account_id),parseInt(from_date),parseInt(to_date))
    }

    @Get('total')
    @ApiResponse({ status: HttpStatus.OK,type:Orders,isArray:true})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Get total'))
    @ApiImplicitQuery({name:'shop_id',type:Number,required:true})
    @ApiImplicitQuery({name:'account_id',type:Number,required:false})
    @ApiImplicitQuery({name:'from_date',type:Number,required:false})
    @ApiImplicitQuery({name:'to_date',type:Number,required:false})
    async getTotalAll(
        @Query('shop_id',new ParseIntPipe()) shop_id:number,
        @Query('account_id') account_id:string=null,
        @Query('from_date') from_date:string=null,
        @Query('to_date') to_date:string=null
        ){
        return await this._orderService.getTotal(shop_id,parseInt(account_id),parseInt(from_date),parseInt(to_date))
    }

    @Post()
    @ApiResponse({ status: HttpStatus.CREATED,type:Orders})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Create Order'))
    async create(@Body() data:OrderDto,@UserD() user:any){
        return this._orderService.createOrder(data,user)
    }
}
