import { Module, forwardRef } from '@nestjs/common';
import { Orders } from './model/order.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OrderService } from './order.service';
import { OrderController } from './order.controller';
import { OrderItemModule } from '../order-item/order-item.module';
import { ShopUserModule } from 'src/shop-user/shop-user.module';

@Module({
    imports:[
        TypeOrmModule.forFeature([Orders]),
        forwardRef(() => OrderItemModule),
        forwardRef(() => ShopUserModule),
    ],
    providers: [OrderService],
    controllers: [OrderController],
})
export class OrderModule {}
