import { Injectable, HttpException, HttpStatus, Inject, forwardRef } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Orders } from './model/order.entity';
import { Repository,LessThanOrEqual, MoreThanOrEqual } from 'typeorm';
import { OrderDto } from './model/order.dto';
import { OrderItemDto } from '../order-item/model/order-item.dto';
import { OrderItemService } from '../order-item/order-item.service';
import { ShopUserService } from 'src/shop-user/shop-user.service';

@Injectable()
export class OrderService {
    constructor(
        @InjectRepository(Orders) private readonly _order:Repository<Orders>,
        @Inject(forwardRef(() => OrderItemService)) readonly _orderItemService: OrderItemService,
        @Inject(forwardRef(() => ShopUserService)) readonly _shopUser: ShopUserService,
        ){
    }
    async getAll(shop_id:number,skip:number,limit:number,account_id:number,from_date:number,to_date:number){
        try {
            let filterAcc = account_id ? {account_id:account_id} : {}
            let filterFrom = from_date ? {order_date:LessThanOrEqual(new Date(to_date).getTime()) } : {}
            let filterTo = to_date ? {order_date:MoreThanOrEqual(new Date(from_date).getTime()) } : {}
            let data = await this._order.find({where:{shop_id:shop_id,...filterAcc,...filterFrom,...filterTo},skip:skip,take:limit,order:{id:-1}})
            return data
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);  
        } 
    }

    async getTotal(shop_id:number,account_id:number,from_date:number,to_date:number){
        try {
            let filterAcc = account_id ? {account_id:account_id} : {}
            let filterFrom = from_date ? {order_date:LessThanOrEqual(new Date(to_date).getTime()) } : {}
            let filterTo = to_date ? {order_date:MoreThanOrEqual(new Date(from_date).getTime()) } : {}
            // await this._order
            let data = await this._order.find({where:{shop_id:shop_id,...filterAcc,...filterFrom,...filterTo},order:{id:-1}})
            let response = { amount:0, net_total:0,total_qty:0 }
            for(let d of data){
                response.amount += parseInt(d.amount)
                response.net_total += parseInt(d.net_total)
                response.total_qty += parseInt(d.total_qty+'')
            }
            return response
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);  
        } 
    }

    async createOrder(data:OrderDto,user:any){
       try {
           let account = await this._shopUser.getUser(user.id)
            let stockList = data.order_item_list
            data.shop_id = account.shop_id
            data.account_id = account.id
            delete data.order_item_list 
            // console.log(data)
            let newOrder = new Orders(data)
            // console.log(newOrder)
            let Order = await this._order.save(newOrder)
            // console.log(Order)
            for(let stock of stockList ){
                await this._orderItemService.createItem({...stock,order_id:Order.id})
            }
            // stockList.forEach(async (stock)=>{
            //     await this._orderItemService.createItem(stock)
            // })
            return Order
            // return {"message":"Created New Order!"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }
}
