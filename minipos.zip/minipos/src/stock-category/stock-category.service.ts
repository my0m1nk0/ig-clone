import { Injectable, HttpException, HttpStatus, Inject, forwardRef } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Category } from './model/category.entity';
import { Repository, Not, Equal } from 'typeorm';
import { CategoryDto } from './model/category.dto';
import { StockItemService } from 'src/stock-item/stock-item.service';

@Injectable()
export class StockCategoryService {
    constructor(
        @InjectRepository(Category) private readonly _category:Repository<Category>,
        @Inject(forwardRef(() => StockItemService)) readonly _itemService: StockItemService,
        ){
    }
    async getAll(shop:number,skip:number,limit:string,parent_id:number){
        try { 
            let filter = parent_id ? { parent_id :parent_id }:{ parent_id:0 }
            let takeLimit = parseInt(limit) > 0 ? {take:parseInt(limit)} : {}
            let data = await this._category.find({where:{shop_id:shop,...filter},skip:skip,...takeLimit,order:{id:-1}})
            return data
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);  
        } 
    }

    async getCategoryByItem(shop:number){
        // let filterParent_id = parent_id ? parent_id : 0
        let data = await this._category.createQueryBuilder().select('max(Category.id) as id, Category.name').innerJoin("item","item","item.category_id = Category.id").groupBy("Category.name").where(`Category.shop_id=${shop} `).getSql();
        //and Category.parent_id=${filterParent_id}
        let response = await this._category.query(data)
        return response
    }

    async createCategory(data:CategoryDto){
        let categorys = await this.checkExist(data.name,data.shop_id,data.parent_id)
        let item = await this._itemService.getCount({category_id:data.parent_id})
        if(categorys.length > 0)
            throw new HttpException("Category is Already Created!", HttpStatus.BAD_REQUEST);
        if(item > 0)
            throw new HttpException("Parent Category is Already Created Stock!", HttpStatus.BAD_REQUEST);
        try {
            let newCategory = new Category(data)
            return await this._category.save(newCategory)
            // return {"message":"Created New Category!"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async updateCategory(data:CategoryDto,id:number){
        let categorys = await this.checkExist(data.name,data.shop_id,data.parent_id,id)
        if(categorys.length > 0)
            throw new HttpException("Category name is Already Exist!", HttpStatus.BAD_REQUEST);
        try{
            let category = await this._category.findOne(id)
            category.name = data.name
            return await this._category.save(category)
            // return {"message":"Updated Category !"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async checkExist(name:string,shop:number,parent_id:number,id:number=0){
        let filter = {name:name,shop_id:shop,parent_id:parent_id}
        return await this._category.find({where:{...filter,id:Not(Equal(id))}})
    }

  
    async deleteCategory(id:number){
        let item =await this._itemService.getCount({category_id:id})
        let category =await this._category.count({where:{parent_id:id}})
        if(category > 0)
            throw new HttpException("This Category Has Child Category!", HttpStatus.BAD_REQUEST);
        if(item > 0)
            throw new HttpException("This Category Has Item!", HttpStatus.BAD_REQUEST);  
        try{
            let category =  await this._category.findOne(id)
            await this._category.remove(category)
            return {"message":"Deleted Category !"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }
}
