import { Module, forwardRef } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Category } from './model/category.entity';
import { StockCategoryService } from './stock-category.service';
import { StockCategoryController } from './stock-category.controller';
import { StockItemModule } from 'src/stock-item/stock-item.module';

@Module({
    imports:[
        TypeOrmModule.forFeature([Category]),
        forwardRef(() => StockItemModule),
    ],
    providers: [StockCategoryService],
    controllers: [StockCategoryController]
})
export class StockCategoryModule {}
