import { Controller, UsePipes, UseGuards, Get, Param, Query, HttpStatus, Post, Body, Put, Delete } from '@nestjs/common';
import { ApiUseTags, ApiBearerAuth, ApiResponse, ApiOperation, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { ValidationPipe } from '../shared/validation.pipe';
import { AuthGuard } from '../shared/guard/auth.guard';
import { StockCategoryService } from './stock-category.service';
import { getOperation } from '../shared/utilities/get-operation';
import { ParseIntPipe } from '../shared/parse-int.pipe';
import { ApiError } from '../shared/api-error.model';
import { SuccessMessage } from '../shared/filters/success.vm';
import { Category } from './model/category.entity';
import { CategoryDto } from './model/category.dto';
const modelName = "Stock Category"

@Controller('shop/:shop_id/stock-category')
@ApiUseTags(modelName)
@UsePipes(new ValidationPipe())
@ApiBearerAuth()
@UseGuards(new AuthGuard())
export class StockCategoryController {
    constructor(private readonly _categoryService:StockCategoryService){}

    @Get()
    @ApiResponse({ status: HttpStatus.OK,type:Category,isArray:true})
    @ApiResponse({ status: HttpStatus.INTERNAL_SERVER_ERROR, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Get Category'))
    @ApiImplicitQuery({name:'skip',type:Number,required:true})
    @ApiImplicitQuery({name:'limit',type:Number,required:false})
    @ApiImplicitParam({name:'shop_id',type:Number,required:true})
    @ApiImplicitQuery({name:'parent_id',type:Number,required:false})
    async getAll(
        @Param('shop_id',new ParseIntPipe()) shop_id:number,
        @Query('skip',new ParseIntPipe()) skip:number,
        @Query('limit') limit:string=null,
        @Query('parent_id') parent_id:number=null,
       ){
        return await this._categoryService.getAll(shop_id,skip,limit,parent_id)
    }

    @Get('has-item')
    @ApiResponse({ status: HttpStatus.OK,type:Category,isArray:true})
    @ApiResponse({ status: HttpStatus.INTERNAL_SERVER_ERROR, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Get Category By Item'))
    @ApiImplicitParam({name:'shop_id',type:Number,required:true})
    // @ApiImplicitQuery({name:'parent_id',type:Number,required:false})
    async getCategoryByItem(
        @Param('shop_id',new ParseIntPipe()) shop_id:number
        // @Query('parent_id') parent_id:number=null,
       ){
        return await this._categoryService.getCategoryByItem(shop_id)
    }

    @Post()
    @ApiResponse({ status: HttpStatus.CREATED,type:Category})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Create Category'))
    @ApiImplicitParam({name:'shop_id',type:Number,required:true})
    async create(@Body() data:CategoryDto,@Param('shop_id',new ParseIntPipe()) shop_id:number){
        data.shop_id = shop_id
        return this._categoryService.createCategory(data)
    }

    @Put(':id')
    @ApiResponse({ status: HttpStatus.OK,type:Category})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Update Category'))
    async update(@Body() data:CategoryDto,@Param('shop_id',new ParseIntPipe()) shop_id:number,@Param('id',new ParseIntPipe()) id:number ){
        data.shop_id = shop_id
        return this._categoryService.updateCategory(data,id)
    }

    @Delete(':id')
    @ApiResponse({ status: HttpStatus.OK,type:SuccessMessage})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Delete Category'))
    async delete(@Param('id',new ParseIntPipe()) id:number){
        return this._categoryService.deleteCategory(id)
    }
}
