import { Entity, Column } from "typeorm";
import { BaseModel } from "../../shared/base.model";
import { ApiModelProperty } from "@nestjs/swagger";

@Entity()
export class Category extends BaseModel{
    @ApiModelProperty()
    @Column()
    shop_id:number

    @ApiModelProperty()
    @Column()
    name:string

    @ApiModelProperty()
    @Column({default:0})
    parent_id:number

    constructor(partial: Partial<Category>) {
        super()
        Object.assign(this, partial);
    }
}