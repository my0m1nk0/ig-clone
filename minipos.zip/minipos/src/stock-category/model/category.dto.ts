import { ApiModelPropertyOptional, ApiModelProperty } from "@nestjs/swagger";

export class CategoryDto{
    
    shop_id?: number

    @ApiModelProperty()
    name:string

    @ApiModelPropertyOptional()
    parent_id:number = 0
}