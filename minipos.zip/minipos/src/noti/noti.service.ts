import { Injectable, forwardRef, Inject, HttpException, HttpStatus } from '@nestjs/common';
import * as fcm from 'fcm-node';
import { ConfigurationService } from 'src/shared/configuration/configuration.service';
import { Configuration } from 'src/shared/configuration/configuration.enum';
import { NotiMessageDto } from './model/noti.dto';
@Injectable()
export class NotiService {
    _fcm:any
    constructor(
        private readonly _config: ConfigurationService
    ){

        this._fcm = new fcm(_config.get(Configuration.FIRE_BASE_KEY))
    }
    async sendNoti(data:NotiMessageDto,tokenArray){
        try {
            
            
            let sendData  = {
                registration_ids:tokenArray,
                collapse_key: '975204145216',
                priority:10,
                data:data
            }
            // console.log(sendData)
             this._fcm.send(sendData,function(err,reponse){
             })
            return {message:"Send notification Success!"}
        } catch (error) {
            console.log(error)
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
