import { Controller, Post, UseGuards, HttpStatus, Body } from '@nestjs/common';
import { ApiBearerAuth, ApiResponse, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from 'src/shared/guard/auth.guard';
import { ApiError } from 'src/shared/api-error.model';
import { getOperation } from 'src/shared/utilities/get-operation';
import { NotiService } from './noti.service';
import { NotiMessageDto } from './model/noti.dto';
import { SuccessMessage } from 'src/shared/filters/success.vm';

@Controller('noti')
export class NotiController {
    constructor(private readonly _notiService:NotiService){}
    @Post()
    @ApiBearerAuth()
    @UseGuards(new AuthGuard())
    @ApiResponse({ status: HttpStatus.OK,type:SuccessMessage })
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation("Noti", 'Sent Noti to All User'))
    async sentNoti(@Body() data:NotiMessageDto){
            // return await this._notiService.sendNoti(data)
            return true
    }
}
