import { ApiModelProperty } from "@nestjs/swagger"
import { IsNotEmpty } from "class-validator"

export class NotiMessageDto{
    @ApiModelProperty()
    @IsNotEmpty()
    title:string
    
    @ApiModelProperty()
    @IsNotEmpty()
    body:any
}