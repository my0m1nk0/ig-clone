import { ApiModelProperty } from "@nestjs/swagger";
import { IsNotEmpty } from "class-validator";

export class ShopLicenseDto{
    @ApiModelProperty()
    @IsNotEmpty()
    shop_id:number

    @ApiModelProperty()
    @IsNotEmpty()
    package_id:number

    @ApiModelProperty()
    @IsNotEmpty()
    no_of_month:number

    @ApiModelProperty()
    @IsNotEmpty()
    start_date:number
}

export class ActiveStatus{
    @ApiModelProperty()
    @IsNotEmpty()
    active_status:boolean
}