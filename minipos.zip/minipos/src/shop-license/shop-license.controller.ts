import { Controller, UsePipes, UseGuards, Get, HttpStatus, Query, Post, Body, Put, Param, Delete } from '@nestjs/common';
import { ApiUseTags, ApiBearerAuth, ApiResponse, ApiOperation, ApiImplicitQuery } from '@nestjs/swagger';
import { ValidationPipe } from '../shared/validation.pipe';
import { AuthGuard } from '../shared/guard/auth.guard';
import { ShopLicense } from './model/shop-license.entity';
import { ApiError } from '../shared/api-error.model';
import { getOperation } from '../shared/utilities/get-operation';
import { ParseIntPipe } from '../shared/parse-int.pipe';
import { ShopLicenseService } from './shop-license.service';
import { SuccessMessage } from '../shared/filters/success.vm';
import { ShopLicenseDto, ActiveStatus } from './model/shop-license.dto';

const modelName = "Shop License"

@Controller('shops/shop-license')
@ApiUseTags(modelName)
@UsePipes(new ValidationPipe())
@ApiBearerAuth()
@UseGuards(new AuthGuard())
export class ShopLicenseController {
    constructor(private readonly _shopLicenseService:ShopLicenseService){}

    @Get()
    @ApiResponse({ status: HttpStatus.OK,type:ShopLicense,isArray:true})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Get Shop License'))
    @ApiImplicitQuery({name:'skip',type:Number,required:true})
    @ApiImplicitQuery({name:'limit',type:Number,required:true})
    @ApiImplicitQuery({name:'shop',type:Number,required:true})
    @ApiImplicitQuery({name:'packAge',type:Number,required:false})
    async getAll(
        @Query('skip',new ParseIntPipe()) skip:number,
        @Query('limit',new ParseIntPipe()) limit:number=null,
        @Query('shop') shop?:string,
        @Query('packAge') packAge?:string
        ){
        return await this._shopLicenseService.getAll(limit,skip,shop,packAge)
    }

    @Post()
    @ApiResponse({ status: HttpStatus.CREATED,type:ShopLicense})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Create Shop License'))
    async create(@Body() data:ShopLicenseDto){
        return this._shopLicenseService.createShopLicense(data)
    }

    @Put(':id')
    @ApiResponse({ status: HttpStatus.OK,type:ShopLicense})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Update Shop License'))
    async update(@Body() data:ShopLicenseDto,@Param('id',new ParseIntPipe()) id:number ){
        return this._shopLicenseService.updateShopLicense(data,id)
    }

    @Delete(':id')
    @ApiResponse({ status: HttpStatus.OK,type:SuccessMessage})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Delete Shop License'))
    async delete(@Param('id',new ParseIntPipe()) id:number){
        // return this._shopLicenseService.deleteShopLicense(id)
        return true
    }

    @Put('active/:id')
    @ApiResponse({ status: HttpStatus.OK,type:ShopLicense})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Update Shop License'))
    async updateActive(@Body() data:ActiveStatus,@Param('id',new ParseIntPipe()) id:number ){
        return this._shopLicenseService.updateActiveStatus(data,id)
    }
}
