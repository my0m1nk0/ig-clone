import { Injectable, HttpException, HttpStatus, forwardRef, Inject } from '@nestjs/common';
import { ShopLicense } from './model/shop-license.entity';
import { Repository, MoreThan, LessThan } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { ShopLicenseDto, ActiveStatus } from './model/shop-license.dto';
import { PackageService } from '../package/package.service';
import { NotEquals } from 'class-validator';

@Injectable()
export class ShopLicenseService {
    constructor(
        @InjectRepository(ShopLicense) private readonly _shopLicense:Repository<ShopLicense>,
        @Inject(forwardRef(() => PackageService)) readonly _packageService: PackageService,
        ){
    }

    async getAll(limit:number,skip:number,shop:string,packAge:string){
        try {
            let filterShop = shop ? {shop_id:shop} : {}
            let filterPackAge = packAge ? {package_id:packAge} : {}  
            let data = await this._shopLicense.find({where:{...filterShop,...filterPackAge},skip:skip,take:limit,order:{active_status:-1,id:-1}});
            return data
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);  
        } 
    }

    async createShopLicense(data:ShopLicenseDto){
        // let shopUsers = await this.checkExist(data.shop_id)
        // if(shopUsers.length > 0)
        //     throw new HttpException("Can't new License.Shop has been License,Please Upgrade License !", HttpStatus.BAD_REQUEST);
        try {
           let date = new Date(data.start_date)
           let packAge = await this._packageService.getDetail(data.package_id)
           let newLicense = new ShopLicense({package_name:packAge.name, price_per_month:packAge.price_per_month, no_of_user:packAge.no_of_user, no_of_stock:packAge.no_of_stock,shop_id:data.shop_id,package_id:packAge.id})
           newLicense.discount = 0
           newLicense.amount = data.no_of_month * packAge.price_per_month
           newLicense.no_of_month = data.no_of_month
           newLicense.start_date =new Date(data.start_date).getTime()
           newLicense.expire_date = new Date(date.setMonth(date.getMonth()+newLicense.no_of_month)).getTime()
           return await this._shopLicense.save(newLicense)
            // return this._shopLicense.create(newLicense)
            // return {"message":"Created New Shop License!"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async checkExist(shopId:number){
        let nowData = new Date().getTime()
        return await this._shopLicense.find(
            {where: {shop_id:shopId,expire_date:MoreThan(nowData)} } 
        )
    }

    async updateShopLicense(data:ShopLicenseDto,id:number){
        try{
            let shopLicense = await this._shopLicense.findOne(id)
            let date = new Date(shopLicense.start_date)
            shopLicense.no_of_month = data.no_of_month
            shopLicense.expire_date = date.setMonth(date.getMonth()+shopLicense.no_of_month)
            return await this._shopLicense.save(shopLicense)
            // return {"message":"Updated Shop License !"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async updateActiveStatus(data:ActiveStatus,id:number){
        try{
            let shopLicense = await this._shopLicense.findOne(id)
            if(data.active_status == true)
                await this._shopLicense.update({shop_id:shopLicense.shop_id},{active_status:false})
            shopLicense.active_status = data.active_status   
            return await this._shopLicense.save(shopLicense)
            // return {"message":"Updated Shop License !"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async deleteShopLicense(id:number){
        try{
            let packAge =  await this._shopLicense.findOne(id)
            await this._shopLicense.remove(packAge)
            return {"message":"Deleted Shop License !"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async checkExpire(shopId){
        let nowDate = new Date().getTime()
        return await this._shopLicense.find({where:{shop_id:shopId,expire_date:MoreThan(nowDate),start_date:LessThan(nowDate),active_status:true},take:1})
    }
}
