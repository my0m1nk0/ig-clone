import { Module, forwardRef } from '@nestjs/common';
import { ShopLicenseService } from './shop-license.service';
import { ShopLicenseController } from './shop-license.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ShopLicense } from './model/shop-license.entity';
import { PackageModule } from '../package/package.module';

@Module({
  imports:[
    TypeOrmModule.forFeature([ShopLicense]),
    forwardRef(() => PackageModule),
  ],
  providers: [ShopLicenseService],
  controllers: [ShopLicenseController],
  exports : [ShopLicenseService]
})
export class ShopLicenseModule {}
