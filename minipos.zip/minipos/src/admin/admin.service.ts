import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Admin } from './model/admin.entity';
import { Repository, Equal, Not, EntityManager } from 'typeorm';
import { AdminDto } from './model/admin.dto';
import { hash, compare } from 'bcryptjs';
import { LoginDto } from './model/login.dto';
import { AuthService } from '../shared/auth/auth.service';
import { AdminLoginVm } from './model/admin-login.vm';
import { Role } from './model/role.enum';

@Injectable()
export class AdminService {
    constructor(
        @InjectRepository(Admin) private readonly _admin:Repository<Admin>,
        private readonly _authService:AuthService,
        ){
    }

    async getAll(skip:number=null,limit:number=null){
        try {
            let data = await this._admin.find({skip: skip,take:limit,order:{id:-1}})
            return data
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);  
        } 
    }

    async createAdmin(data:AdminDto){
        let admin = await this._admin.find({where:{username:data.username},order:{id:"DESC"}})
        if(admin.length > 0)
            throw new HttpException("Username is Already Created!", HttpStatus.BAD_REQUEST);
        try {
            let newAdmin = new Admin(data)
            newAdmin.password = await hash(data.password,10)
            await this._admin.save(newAdmin)
            return {"message":"Created New Admin!"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async updateAdmin(data:AdminDto,id:number){
        let admin = await this._admin.find({where:{username:data.username,id:Not(Equal(id))},order:{id:"DESC"}})
        if(admin.length > 0)
            throw new HttpException("Username is Already Exist!", HttpStatus.BAD_REQUEST);
        try{
            let admin = await this._admin.findOne(id)
            admin.username = data.username
            admin.account_type = data.account_type
            return await this._admin.save(admin)
            // return {"message":"Updated Admin !"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async changePassword(newPassword:string,id:number){
        try{
            let admin = await this._admin.findOne(id)
            admin.password = await hash(newPassword,10)
            await this._admin.save(admin)
            return {"message":"Updated Admin Passsword !"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async deleteAdmin(id:number){
        try{
            let admin =  await this._admin.findOne(id)
            await this._admin.remove(admin)
            return {"message":"Deleted Admin !"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async login(data:LoginDto){
        let response = new AdminLoginVm()
        let admin = await this._admin.find({username:data.username})

        if(admin.length == 0)
            throw new HttpException("Username is Invalid!", HttpStatus.BAD_REQUEST);

        let comfirm = await compare(data.password,admin[0].password)
        if(!comfirm)
            throw new HttpException("Wrong Password", HttpStatus.BAD_REQUEST);

        response.token = await this._authService.generateToken(admin[0].id,admin[0].account_type)
        response.user = admin[0]
        
        return response
    }

    async updateDevice(id,device_token){
        let admin = await this._admin.findOne(id)
        admin.device_token = device_token
        return await this._admin.save(admin)
    }

    async findAndGetToken(){
        return await this._admin.find({where:{account_type:Role.ADMIN}})
    }

    
}
