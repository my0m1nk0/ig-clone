import { Controller, Get, Post, Body, UseGuards, HttpStatus, UsePipes, Query, Put, Param, Delete } from '@nestjs/common';
import { ApiUseTags, ApiBearerAuth, ApiResponse, ApiOperation, ApiImplicitQuery, ApiImplicitBody } from '@nestjs/swagger';
import { AdminService } from './admin.service';
import { AdminDto, ChangePassword } from './model/admin.dto';
import { AuthGuard } from '../shared/guard/auth.guard';
import { ApiError } from '../shared/api-error.model';
import { getOperation } from '../shared/utilities/get-operation';
import { ValidationPipe } from '../shared/validation.pipe';
import { ParseIntPipe } from '../shared/parse-int.pipe';
import { AdminLoginVm } from './model/admin-login.vm';
import { LoginDto } from './model/login.dto';
import { SuccessMessage } from '../shared/filters/success.vm';
import { Admin } from './model/admin.entity';
const modelName = 'Admin'

@Controller('admin')
@ApiUseTags(modelName)
@UsePipes(new ValidationPipe())
export class AdminController {
    constructor(private readonly _admin:AdminService){}

    @Get()
    @ApiBearerAuth()
    @UseGuards(new AuthGuard())
    @ApiResponse({ status: HttpStatus.OK,type:Admin,isArray:true})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Get Admin'))
    @ApiImplicitQuery({name:'skip',type:Number,required:true})
    @ApiImplicitQuery({name:'limit',type:Number,required:true})
    async getAll(@Query('skip',new ParseIntPipe()) skip:number,@Query('limit',new ParseIntPipe()) limit:number=null,){
        return await this._admin.getAll(skip,limit)
    }

    @Post()
    @ApiBearerAuth()
    @UseGuards(new AuthGuard())
    @ApiResponse({ status: HttpStatus.CREATED,type:SuccessMessage})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Create Admin'))
    async create(@Body() data:AdminDto){
        return this._admin.createAdmin(data)
    }

    @Put(':id')
    @ApiBearerAuth()
    @UseGuards(new AuthGuard())
    @ApiResponse({ status: HttpStatus.OK,type:Admin})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Update Admin'))
    async update(@Body() data:AdminDto,@Param('id',new ParseIntPipe()) id:number ){
        return this._admin.updateAdmin(data,id)
    }

    @Put('password/:id')
    @ApiBearerAuth()
    @UseGuards(new AuthGuard())
    @ApiResponse({ status: HttpStatus.OK,type:SuccessMessage})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Change Password Admin'))
    @ApiImplicitBody({name:'ChangePassword',type:ChangePassword})
    async updatePassword(@Body('password') password:string,@Param('id',new ParseIntPipe()) id:number ){
        return this._admin.changePassword(password,id)
    }

    @Delete(':id')
    @ApiBearerAuth()
    @UseGuards(new AuthGuard())
    @ApiResponse({ status: HttpStatus.OK,type:SuccessMessage})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Delete Admin'))
    async delete(@Param('id',new ParseIntPipe()) id:number){
        return this._admin.deleteAdmin(id)
    }

    @Post('login')
    @ApiResponse({ status: HttpStatus.OK,type:AdminLoginVm})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Login Admin'))
    async login(@Body() data:LoginDto ){
        return this._admin.login(data)
    }
}
