import { ApiModelProperty, ApiModelPropertyOptional } from "@nestjs/swagger";
import { IsString, IsEnum } from "class-validator";
import { Role } from "./role.enum";
import { EnumToArray } from "../../shared/utilities/enum-to-array";

export class AdminDto{

    @ApiModelProperty()
    @IsString()
    username:string

    @ApiModelPropertyOptional()
    password?:string

    @ApiModelProperty({default:Role.ADMIN,enum:EnumToArray(Role)})
    @IsEnum(Role)
    account_type:Role

}

export class ChangePassword{
    @ApiModelProperty()
    @IsString()
    password:string
}