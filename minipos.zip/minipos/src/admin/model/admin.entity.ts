import { Entity, Column, PrimaryGeneratedColumn, BaseEntity } from "typeorm";
import { Role } from "./role.enum";
import { BaseModel } from "../../shared/base.model";
import { ApiModelProperty, ApiModelPropertyOptional } from "@nestjs/swagger";

@Entity()
export class Admin extends BaseModel{
    @ApiModelProperty()
    @Column()
    username:string

    @ApiModelProperty()
    @Column()
    password:string
    
    @ApiModelProperty()
    @Column({type:'enum',enum:Role,default:Role.ADMIN})
    account_type:string

    @ApiModelPropertyOptional()
    @Column({nullable:true})
    device_token:string
    
    constructor(partial: Partial<Admin>) {
        super()
        Object.assign(this, partial);
    }
}