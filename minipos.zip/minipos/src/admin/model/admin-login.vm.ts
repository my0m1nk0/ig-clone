import { ApiModelProperty } from "@nestjs/swagger";
import { Admin } from "./admin.entity";
import { ShopUser } from "../../shop-user/model/shop-user.entity";

export class AdminLoginVm{
    @ApiModelProperty()
    token:string

    @ApiModelProperty()
    user:Admin | ShopUser
}