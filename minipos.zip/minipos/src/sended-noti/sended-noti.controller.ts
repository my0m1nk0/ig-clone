import { Controller, Get, HttpStatus, UsePipes, ValidationPipe, ParseIntPipe, Query, Post, Body, Put, Delete, Param } from '@nestjs/common';
import { SendedNotiService } from './sended-noti.service';
import { ApiResponse, ApiUseTags, ApiOperation, ApiImplicitQuery } from '@nestjs/swagger';
import { Noti } from './model/noti.entity';
import { ApiError } from 'src/shared/api-error.model';
import { getOperation } from 'src/shared/utilities/get-operation';
import { RequestLicense } from 'src/request-license/model/request-license.entity';
import { NotiDto } from './model/noti.dto';
const modelName = 'Send Noti'

@Controller('send-noti')
@ApiUseTags(modelName)
@UsePipes(new ValidationPipe())
export class SendedNotiController {
    constructor(private readonly _notiService:SendedNotiService){}

    @Get()
    @ApiResponse({ status: HttpStatus.OK,type:Noti,isArray:true})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Get Sended Noti'))
    @ApiImplicitQuery({name:'skip',type:Number,required:true})
    @ApiImplicitQuery({name:'limit',type:Number,required:true})
    @ApiImplicitQuery({name:'admin',type:Boolean,required:true})
    @ApiImplicitQuery({name:'shop',type:Number,required:true})
    @ApiImplicitQuery({name:'user',type:Number,required:true})
    async getAll(
        @Query('skip',new ParseIntPipe()) skip:number,
        @Query('limit',new ParseIntPipe()) limit:number=null,
        @Query('admin') admin:boolean,
        @Query('user') user:string,
        @Query('shop') shop?:string,
        ){
        return await this._notiService.getAll(limit,skip,shop,user,admin)
    }

    @Post()
    @ApiResponse({ status: HttpStatus.CREATED,type:RequestLicense})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Create Shop License'))
    async create(@Body() data:NotiDto){
        return this._notiService.createNoti(data)
    }

    // @Put(':id')
    // @ApiResponse({ status: HttpStatus.OK,type:RequestLicense})
    // @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    // @ApiOperation(getOperation(modelName, 'Update Shop License'))
    // async update(@Body() data:NotiDto,@Param('id',new ParseIntPipe()) id:number ){
    //     return this._notiService.updateRequestLicense(data,id)
    // }

    // @Delete(':id')
    // @ApiResponse({ status: HttpStatus.OK,type:SucessMessage})
    // @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    // @ApiOperation(getOperation(modelName, 'Delete Shop License'))
    // async delete(@Param('id',new ParseIntPipe()) id:number){
    //     return this._notiService.deleteShopLicense(id)
    //     // return true
    // }
}
