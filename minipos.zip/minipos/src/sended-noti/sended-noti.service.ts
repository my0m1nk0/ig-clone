import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Noti } from './model/noti.entity';
import { Repository } from 'typeorm';
import { NotiDto } from './model/noti.dto';

@Injectable()
export class SendedNotiService {
    constructor(
        @InjectRepository(Noti) private readonly _noti:Repository<Noti>,
        ){
    }
    async getAll(limit:number,skip:number,shop:string,user:string,admin:boolean){
        try {
            let filterShop = shop ? {shop_id:shop} : {}
            let filterUser = user ? {to:user} : {} 
            let data = await this._noti.find({where:{...filterShop,...filterUser,type_client:!admin},skip:skip,take:limit,order:{id:-1}});
            return data
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);  
        } 
    }

    async createNoti(data:NotiDto){
        // let shopUsers = await this.checkExist(data.shop_id)
        // if(shopUsers.length > 0)
        //     throw new HttpException("Can't new License.Shop has been License,Please Upgrade License !", HttpStatus.BAD_REQUEST);
        try {
           
           let newLicense = new Noti(data)
           return await this._noti.save(newLicense)
            // return this._shopLicense.create(newLicense)
            // return {"message":"Created New Shop License!"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

}
