import { Module } from '@nestjs/common';
import { SendedNotiController } from './sended-noti.controller';
import { SendedNotiService } from './sended-noti.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Noti } from './model/noti.entity';

@Module({
  imports:[
    TypeOrmModule.forFeature([Noti]),
  ],
  controllers: [SendedNotiController],
  providers: [SendedNotiService],
  exports:[SendedNotiService]
})
export class SendedNotiModule {}
