import { Entity, Column } from "typeorm"
import { BaseModel } from "src/shared/base.model"
import { ApiModelProperty } from "@nestjs/swagger"

@Entity()
export class Noti extends BaseModel {

    @ApiModelProperty()
    @Column({type:'text'})
    message:string

    @ApiModelProperty()
    @Column({type:'text'})
    title:string

    @ApiModelProperty()
    @Column()
    to:number

    @ApiModelProperty()
    @Column({nullable:true})
    shop_id:number

    @ApiModelProperty()
    @Column({nullable:true})
    group:number

    @ApiModelProperty()
    @Column({default:true})
    type_client:boolean

    constructor(partial: Partial<Noti>) {
        super()
        Object.assign(this, partial);
    }
}