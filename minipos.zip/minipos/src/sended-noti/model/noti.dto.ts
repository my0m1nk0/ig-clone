import { ApiModelProperty, ApiModelPropertyOptional } from "@nestjs/swagger";
import { IsNotEmpty } from "class-validator";

export class NotiDto{
    @ApiModelProperty()
    @IsNotEmpty()
    to:number

    @ApiModelProperty()
    @IsNotEmpty()
    shop:number

    @ApiModelProperty()
    @IsNotEmpty()
    message:string

    @ApiModelProperty()
    @IsNotEmpty()
    title:string

    @ApiModelPropertyOptional()
    group?:number

    @ApiModelProperty()
    @IsNotEmpty()
    type_client:boolean
}