import { ApiModelProperty, ApiModelPropertyOptional } from "@nestjs/swagger";
import { IsNotEmpty, IsString } from "class-validator";

export class ShopDto {

    @ApiModelProperty()
    @IsNotEmpty()
    @IsString()
    name:string

    @ApiModelProperty()
    @IsNotEmpty()
    @IsString()
    phone:string
    
    @ApiModelPropertyOptional()
    gmail?:string

    @ApiModelProperty()
    @IsNotEmpty()
    @IsString()
    logo:string

    shop_code:string 

    @ApiModelProperty()
    @IsNotEmpty()
    tax:number

    @ApiModelProperty()
    @IsNotEmpty()
    service_charges:number

    @ApiModelProperty()
    @IsNotEmpty()
    address:string

    constructor(partial: Partial<ShopDto>){
        Object.assign(this, partial);
        this.shop_code = `SHP_${new Date().getTime()}_`
    }
}