import { BaseModel } from "../../shared/base.model";
import { Entity, Column, BeforeInsert, BeforeUpdate } from "typeorm";
import { ApiModelProperty } from "@nestjs/swagger";
import { Configuration } from "../../shared/configuration/configuration.enum";
import { get } from "config"

@Entity()
export class Shop extends BaseModel {
    @ApiModelProperty()
    @Column({type:'varchar',unique:true})
    name:string

    @ApiModelProperty()
    @Column({type:'varchar',unique:true})
    phone:string

    @ApiModelProperty()
    @Column({type:'varchar',nullable:true})
    gmail?:string

    @ApiModelProperty()
    @Column({type:'varchar'})
    logo:string

    @ApiModelProperty()
    @Column({type:'text',nullable:true})
    logo_url?:string

    @ApiModelProperty()
    @Column({type:'varchar',unique:true})
    shop_code:string

    @ApiModelProperty()
    @Column({default:0})
    tax:number

    @ApiModelProperty()
    @Column({default:0})
    service_charges:number

    @ApiModelProperty()
    @Column({type:'text'})
    address:string

    @ApiModelProperty()
    @Column({default:1})
    active_status:number

    @BeforeInsert()
    updateInesrtData() {
        let s3b = process.env.S3_BUCKET || get(Configuration.S3_BUCKET);
        const img = this.logo || 'no-images.png';
        this.logo_url =  `https://naing-pos.s3-ap-southeast-1.amazonaws.com/${img}`
    }

    @BeforeUpdate()
    updateData() {
        let s3b = process.env.S3_BUCKET || get(Configuration.S3_BUCKET);
        const img = this.logo || 'no-images.png';
        this.logo_url =  `https://naing-pos.s3-ap-southeast-1.amazonaws.com/${img}`
    }
    constructor(partial: Partial<Shop>) {
        super()
        Object.assign(this, partial);
    }
}