import { Module, forwardRef } from '@nestjs/common';
import { ShopController } from './shop.controller';
import { ShopService } from './shop.service';
import { Shop } from './model/shop.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ShopUserModule } from '../shop-user/shop-user.module';
import { ShopLicenseModule } from '../shop-license/shop-license.module';

@Module({
  imports:[
    TypeOrmModule.forFeature([Shop]),
    forwardRef(() => ShopUserModule),
    forwardRef(() => ShopLicenseModule),
  ],
  controllers: [ShopController],
  providers: [ShopService],
  exports : [ShopService]
})
export class ShopModule {}
