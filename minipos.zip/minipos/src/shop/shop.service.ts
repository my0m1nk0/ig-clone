import { Injectable, HttpException, HttpStatus, Inject, forwardRef } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Shop } from './model/shop.entity';
import { Repository, Not, Equal } from 'typeorm';
import { ShopDto } from './model/shop.dto';
import { ShopUserService } from '../shop-user/shop-user.service';
import { ShopUserDto } from '../shop-user/model/shop-user.dto';
import { Role } from '../admin/model/role.enum';
import { ShopLicenseService } from '../shop-license/shop-license.service';
import { ShopLicenseDto, ActiveStatus } from '../shop-license/model/shop-license.dto';
import { LoginDto } from '../admin/model/login.dto';
import { AdminLoginVm } from '../admin/model/admin-login.vm';
import { ShopUser } from 'src/shop-user/model/shop-user.entity';

@Injectable()
export class ShopService {
    constructor(
        @Inject(forwardRef(() => ShopUserService)) readonly _shopUserService: ShopUserService,
        @InjectRepository(Shop) private readonly _shop:Repository<Shop>,
        @Inject(forwardRef(() => ShopLicenseService)) readonly _shopLicenseService: ShopLicenseService,
        ){
    }

    async getAll(limit:number,skip:number){
        try {            
            let data = await this._shop.find({where:{active_status:1},skip:skip,take:limit,order:{id:-1}});
            return data
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);  
        } 
    }

    async getById(id:number){
        try {            
            let data = await this._shop.find({id:id});
            if(data.length > 0)
                return data[0]
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);  
        } 
        throw new HttpException("Invalid Id", HttpStatus.BAD_REQUEST); 
    }

    async createShop(data:ShopDto,package_id:number,no_month:number,start_date:number){
        data = new ShopDto(data)
        let shops = await this._shop.find(
            {where:[
                {name:data.name},
                // {gmail:data.gmail},
                {phone:data.phone}
            ]}
        )
        if(shops.length > 0)
            throw new HttpException("Shop Name is Already Created !", HttpStatus.BAD_REQUEST);
        try {
            let count = await this._shop.count()
            let newShop = new Shop(data)
            newShop.shop_code += count+1
            let createdShop = await this._shop.save(newShop)
            await this.createShopUser(createdShop)
            await this.createLicense(createdShop.id,package_id,no_month,start_date)
            return createdShop 
            // return {"message":"Created New Shop!"}
        } catch (error) {
            // console.log(error);
            
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async loginShop(data:LoginDto){
        let response = await this._shopUserService.loginUser(data)
        let user:ShopUser = response.user as ShopUser
        let shop =await this._shop.findOne(user.shop_id)
        if(shop){
            let expired = await this._shopLicenseService.checkExpire(shop.id)
            if(expired.length > 0 && shop.active_status == 1)
                return response
            else
                throw new HttpException({message:"Your Shop Is Expired",shop:shop.id}, HttpStatus.PAYMENT_REQUIRED); 
        }
        throw new HttpException("Your Shop Is Suspended", HttpStatus.BAD_REQUEST); 
    }

    async createShopUser(createdShop): Promise<void>{
        let newUser = new ShopUserDto()
        newUser.username = createdShop.name.replace(" ","").toLowerCase() + createdShop.id
        newUser.gmail = createdShop.gmail
        newUser.phone = createdShop.phone
        newUser.shop_code = createdShop.shop_code
        newUser.shop_id = createdShop.id
        newUser.phone = createdShop.phone
        newUser.account_type = Role.SHOP_OWNER
        newUser.password = createdShop.phone
        await this._shopUserService.createShopUser(newUser,true)
    }

    async createLicense(shop_id:number,package_id:number,no_month:number,start_date:number): Promise<void> {
        let newLicense = new ShopLicenseDto()
        newLicense.shop_id=shop_id
        newLicense.package_id=package_id
        newLicense.no_of_month=no_month
        newLicense.start_date=start_date
        let license = await this._shopLicenseService.createShopLicense(newLicense)
        let active = new ActiveStatus()
        active.active_status = true
        await this._shopLicenseService.updateActiveStatus(active,license.id)
    }

    async updateShop(data:ShopDto,id:number){
        let shops = await this._shop.find(
            {where:[
                {name:data.name,id:Not(Equal(id))},
                // {gmail:data.gmail,id:Not(Equal(id))},
                {phone:data.phone,id:Not(Equal(id))}
            ]}
            )
        // let users = await this._shopUserService.checkExist(data.name,data.phone)
        if(shops.length > 0)
            throw new HttpException("Shop name Or Phone Number is Already Exist !", HttpStatus.BAD_REQUEST);
        // if(users.length > 0)
        //     throw new HttpException("Shop admin name is Already Exist !", HttpStatus.BAD_REQUEST);
        try{
            let shop = await this._shop.findOne(id)
            shop.name = data.name
            shop.phone = data.phone
            shop.gmail = data.gmail
            shop.logo = data.logo
            // shop.shop_code = data.shop_code
            shop.tax = data.tax
            shop.service_charges = data.service_charges
            shop.address = data.address
            return await this._shop.save(shop)
            // return {"message":"Updated Shop !"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async deleteShop(id:number){
        try{
            let shop =  await this._shop.findOne(id)
            shop.active_status = 0
            await this._shop.save(shop)
            // await this._shop.remove(shop)
            return {"message":"Deleted Shop !"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }
}
