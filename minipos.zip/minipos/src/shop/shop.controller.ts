import { Controller, UsePipes, UseGuards, ValidationPipe, HttpStatus, Get, Post, Query, Put, Delete, Body, Param } from '@nestjs/common';
import { ApiUseTags, ApiBearerAuth, ApiResponse, ApiOperation, ApiImplicitQuery } from '@nestjs/swagger';
import { ShopService } from './shop.service';
import { AuthGuard } from '../shared/guard/auth.guard';
import { Package } from '../package/model/package.entity';
import { getOperation } from '../shared/utilities/get-operation';
import { SuccessMessage } from '../shared/filters/success.vm';
import { ApiError } from '../shared/api-error.model';
import { ShopDto } from './model/shop.dto';
import { ParseIntPipe } from '../shared/parse-int.pipe';
import { Shop } from './model/shop.entity';
import { LoginDto } from '../admin/model/login.dto';
import { AdminLoginVm } from '../admin/model/admin-login.vm';

const modelName = 'Shop'

@Controller('shop')
@ApiUseTags(modelName)
@UsePipes(new ValidationPipe())
export class ShopController {
    constructor(private readonly _shop:ShopService){}

    @Get()
    @ApiBearerAuth()
    @UseGuards(new AuthGuard())
    @ApiResponse({ status: HttpStatus.OK,type:Shop,isArray:true})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Get Shop'))
    @ApiImplicitQuery({name:'skip',type:Number,required:true})
    @ApiImplicitQuery({name:'limit',type:Number,required:true})
    async getAll(@Query('skip',new ParseIntPipe()) skip:number,@Query('limit',new ParseIntPipe()) limit:number=null){
        return await this._shop.getAll(limit,skip)
    }

    @Get('info/:id')
    @ApiBearerAuth()
    @UseGuards(new AuthGuard())
    @ApiResponse({ status: HttpStatus.OK,type:Shop})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Get Shop Info'))
    async getById(@Param('id',new ParseIntPipe()) id:number){
        return await this._shop.getById(id)
    }

    @Post('')
    @ApiBearerAuth()
    @UseGuards(new AuthGuard())
    @ApiResponse({ status: HttpStatus.CREATED,type:Shop})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Create Shop'))
    @ApiImplicitQuery({name:'package_id',type:Number,required:true})
    @ApiImplicitQuery({name:'no_month',type:Number,required:true})
    @ApiImplicitQuery({name:'start_date',type:Number,required:true})
    async create(
        @Body() data:ShopDto,
        @Query('package_id',new ParseIntPipe()) package_id:number,
        @Query('start_date',new ParseIntPipe()) start_date:number,
        @Query('no_month',new ParseIntPipe()) no_month:number){
        return this._shop.createShop(data,package_id,no_month,start_date)
    }

    @Post('login')
    @ApiResponse({ status: HttpStatus.OK,type:AdminLoginVm})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Login Shop'))
    async login(@Body() data:LoginDto){
        return this._shop.loginShop(data)
    }

    @Put(':id')
    @ApiBearerAuth()
    @UseGuards(new AuthGuard())
    @ApiResponse({ status: HttpStatus.OK,type:Shop})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Update Shop'))
    async update(@Body() data:ShopDto,@Param('id',new ParseIntPipe()) id:number ){
        return this._shop.updateShop(data,id)
    }

    @Delete(':id')
    @ApiBearerAuth()
    @UseGuards(new AuthGuard())
    @ApiResponse({ status: HttpStatus.OK,type:SuccessMessage})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Delete Shop'))
    async delete(@Param('id',new ParseIntPipe()) id:number){
        return this._shop.deleteShop(id)
    }
}
