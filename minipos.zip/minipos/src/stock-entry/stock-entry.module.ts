import { Module, forwardRef } from '@nestjs/common';
import { StockEntryController } from './stock-entry.controller';
import { StockEntryService } from './stock-entry.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { StockEntry } from './model/stock-entry.entity';
import { StockItemModule } from '../stock-item/stock-item.module';

@Module({
  imports:[
    TypeOrmModule.forFeature([StockEntry]),
    forwardRef(() => StockItemModule)
  ],
  controllers: [StockEntryController],
  providers: [StockEntryService],
  
})
export class StockEntryModule {}
