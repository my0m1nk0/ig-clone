import { ApiModelProperty, ApiModelPropertyOptional } from "@nestjs/swagger";
import { IsNotEmpty, IsEnum } from "class-validator";
import { EntryType } from "./entry-type.enum";
import { EnumToArray } from "../../shared/utilities/enum-to-array";

export class StockEntryDto {
    @ApiModelProperty()
    @IsNotEmpty()
    item_id:number

    @ApiModelProperty()
    @IsNotEmpty()
    no_of_stock:number

    @ApiModelProperty({enum:EnumToArray(EntryType),default:EntryType.ADD})
    @IsNotEmpty()
    @IsEnum(EntryType)
    type:EntryType = EntryType.ADD
}