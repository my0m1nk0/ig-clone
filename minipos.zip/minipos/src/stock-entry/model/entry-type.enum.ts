export enum EntryType{
    ADD = 'add',
    MINUS = 'minus'
}