import { Entity, Column } from "typeorm";
import { BaseModel } from "../../shared/base.model";
import { ApiModelProperty } from "@nestjs/swagger";
import { EntryType } from "./entry-type.enum";

@Entity()
export class StockEntry extends BaseModel{
   
    @ApiModelProperty()
    @Column()
    item_id:number

    @ApiModelProperty()
    @Column()
    no_of_stock:number

    @ApiModelProperty()
    @Column({enum:EntryType,default:EntryType.ADD})
    type:EntryType
    
    constructor(partial: Partial<StockEntry>) {
        super()
        Object.assign(this, partial);
    }
}