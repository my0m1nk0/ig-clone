import { Injectable, HttpException, HttpStatus, Inject, forwardRef } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { StockEntry } from './model/stock-entry.entity';
import { StockEntryDto } from './model/stcok-entry.dto';
import { StockItemService } from '../stock-item/stock-item.service';
import { EntryType } from './model/entry-type.enum';

@Injectable()
export class StockEntryService {
    constructor(
        @InjectRepository(StockEntry) private readonly _itemEntry:Repository<StockEntry>,
        @Inject(forwardRef(() => StockItemService)) readonly _stockService: StockItemService,
        ){
    }
    async getAll(item_id:number,skip:number,limit:number){
        try {
            let data = await this._itemEntry.find({where:{item_id:item_id,type:EntryType.ADD},skip:skip,take:limit,order:{id:-1}})
            return data
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);  
        } 
    }

    async createEntry(data:StockEntryDto){
        let newCategory = new StockEntry(data)
        await this._stockService.entryStock(newCategory.item_id,newCategory.no_of_stock,newCategory.type)
        try {   
            return await this._itemEntry.save(newCategory)
            // return {"message":"Created New Stock Entry!"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }
  
    async deleteEntry(id:number){
        let itemEntry =  await this._itemEntry.findOne(id)
        let type = itemEntry.type == EntryType.ADD ? EntryType.MINUS : EntryType.ADD
        await this._stockService.entryStock(itemEntry.item_id,itemEntry.no_of_stock,type)
        try{
           
            return await this._itemEntry.remove(itemEntry)
            // return {"message":"Deleted Stock Entry!"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }
}
