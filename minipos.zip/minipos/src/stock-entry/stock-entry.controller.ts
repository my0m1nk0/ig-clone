import { Controller, UsePipes, UseGuards, Get, HttpStatus, Param, Query, Post, Body, Delete } from '@nestjs/common';
import { ApiUseTags, ApiBearerAuth, ApiResponse, ApiOperation, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { ValidationPipe } from '../shared/validation.pipe';
import { AuthGuard } from '../shared/guard/auth.guard';
import { StockEntryService } from './stock-entry.service';
import { StockEntry } from './model/stock-entry.entity';
import { ApiError } from '../shared/api-error.model';
import { getOperation } from '../shared/utilities/get-operation';
import { ParseIntPipe } from '../shared/parse-int.pipe';
import { SuccessMessage } from '../shared/filters/success.vm';
import { StockEntryDto } from './model/stcok-entry.dto';
const modelName = "Stock Entry"

@Controller('stock-entry')
@ApiUseTags(modelName)
@UsePipes(new ValidationPipe())
@ApiBearerAuth()
@UseGuards(new AuthGuard())
export class StockEntryController {
    constructor(private readonly _entryService:StockEntryService){}

    @Get()
    @ApiResponse({ status: HttpStatus.OK,type:StockEntry,isArray:true})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Get Stock Entry'))
    @ApiImplicitQuery({name:'skip',type:Number,required:true})
    @ApiImplicitQuery({name:'limit',type:Number,required:true})
    @ApiImplicitQuery({name:'item_id',type:Number,required:true})
    async getAll(
        @Query('skip',new ParseIntPipe()) skip:number,
        @Query('limit',new ParseIntPipe()) limit:number = null,
        @Query('item_id',new ParseIntPipe()) item_id:number
        ){
        return await this._entryService.getAll(item_id,skip,limit,)
    }

    @Post()
    @ApiResponse({ status: HttpStatus.CREATED,type:StockEntry})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Create Stock Entry'))
    async create(
        @Body() data:StockEntryDto
        ){
        return this._entryService.createEntry(data)
    }


    @Delete(':id')
    @ApiResponse({ status: HttpStatus.OK,type:SuccessMessage})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Delete Item'))
    async delete(@Param('id',new ParseIntPipe()) id:number){
        return this._entryService.deleteEntry(id)
    }
}
