import { Controller, UsePipes, UseGuards, ValidationPipe, Get, HttpStatus, Query, Post, Body, Param, Put, Delete } from '@nestjs/common';
import { ShopUserService } from './shop-user.service';
import { ApiUseTags, ApiBearerAuth, ApiResponse, ApiOperation, ApiImplicitQuery, ApiImplicitBody, ApiImplicitParam } from '@nestjs/swagger';
import { AuthGuard } from '../shared/guard/auth.guard';
import { getOperation } from '../shared/utilities/get-operation';
import { ParseIntPipe } from '../shared/parse-int.pipe';
import { ApiError } from '../shared/api-error.model';
import { ShopUser } from './model/shop-user.entity';
import { SuccessMessage } from '../shared/filters/success.vm';
import { ShopUserDto, CreateShopUser } from './model/shop-user.dto';
import { ChangePassword } from '../admin/model/admin.dto';
import { EnumToArray } from '../shared/utilities/enum-to-array';
import { Role } from '../admin/model/role.enum';
const modelName = 'Shop User'


@Controller('shops/shop-user')
@ApiUseTags(modelName)
@UsePipes(new ValidationPipe())
@ApiBearerAuth()
@UseGuards(new AuthGuard())
export class ShopUserController {
    constructor(private readonly _shop:ShopUserService){}

    @Get()
    @ApiResponse({ status: HttpStatus.OK,type:ShopUser,isArray:true})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Get Shop User'))
    @ApiImplicitQuery({name:'skip',type:Number,required:true})
    @ApiImplicitQuery({name:'limit',type:Number,required:true})
    @ApiImplicitQuery({name:'shop',type:Number,required:false})
    @ApiImplicitQuery({name:'user_role',type:Role,required:false})
    async getAll(
        @Query('skip',new ParseIntPipe()) skip:number,
        @Query('limit',new ParseIntPipe()) limit:number=null,
        @Query('shop',new ParseIntPipe()) shop:number,
        @Query('user_role') user_role?:Role
        ){
        return await this._shop.getAll(limit,skip,shop,user_role)
    }

    @Get('role')
    @ApiResponse({ status: HttpStatus.OK,})
    @ApiOperation(getOperation(modelName, 'Get Shop User Role'))
    async getRole(){
        let role = EnumToArray(Role)
        role.splice(0,2)
        return role
    }

    @Post()
    @ApiResponse({ status: HttpStatus.CREATED,type:ShopUser})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Create Shop User'))
    @ApiImplicitQuery({name:'shop_id',type:String,required:true})
    @ApiImplicitQuery({name:'shop_code',type:String,required:true})
    async create(@Body() data:CreateShopUser,@Query('shop_id',new ParseIntPipe()) shop_id:number,@Query('shop_code') shop_code:string){
        data.shop_code = shop_code
        data.shop_id = shop_id
        return this._shop.createShopUser(data)
    }

    @Put(':id')
    @ApiResponse({ status: HttpStatus.OK,type:ShopUser})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Update Shop User'))
    // 
    @ApiImplicitParam({name:'id',type:String,required:true})
    async update(@Body() data:ShopUserDto,@Param('id',new ParseIntPipe()) id:number,){
        return this._shop.updateShopUser(data,id)
        return id
    }

    @Put('password/:id')
    @ApiBearerAuth()
    @UseGuards(new AuthGuard())
    @ApiResponse({ status: HttpStatus.OK,type:SuccessMessage})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Change Password Shop User'))
    @ApiImplicitBody({name:'ChangePassword',type:ChangePassword})
    @ApiImplicitParam({name:'id',type:String,required:true})
    async updatePassword(@Param('id',new ParseIntPipe()) id:number,@Body('password') password:string ){
        return this._shop.changePassword(password,id)
    }

    @Delete(':id')
    @ApiResponse({ status: HttpStatus.OK,type:SuccessMessage})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Delete Shop User'))
    async delete(@Param('id',new ParseIntPipe()) id:number){
        return this._shop.deleteShopUser(id)
    }
}
