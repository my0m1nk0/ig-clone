import { Module, forwardRef } from '@nestjs/common';
import { ShopUserService } from './shop-user.service';
import { ShopUserController } from './shop-user.controller';
import { ShopUser } from './model/shop-user.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ShopLicenseModule } from 'src/shop-license/shop-license.module';

@Module({
  imports:[
    TypeOrmModule.forFeature([ShopUser]),
    forwardRef(() => ShopLicenseModule),
  ],
  providers: [ShopUserService],
  controllers: [ShopUserController],
  exports:[ShopUserService]
})
export class ShopUserModule {}
