import { BaseModel } from "../../shared/base.model";
import { Entity, Column } from "typeorm";
import { ApiModelProperty, ApiModelPropertyOptional } from "@nestjs/swagger";
import { Role } from "../../admin/model/role.enum";

@Entity()
export class ShopUser extends BaseModel {
    @ApiModelProperty()
    @Column({type:'varchar',unique:true})
    username:string

    @ApiModelProperty()
    @Column({type:'varchar',unique:true})
    phone:string

    @ApiModelProperty()
    @Column({type:'varchar',nullable:true})
    gmail?:string

    @ApiModelProperty()
    @Column({type:'enum',enum:Role,default:Role.SHOP_CASHER})
    account_type:string

    @ApiModelProperty()
    @Column()
    shop_id:number

    @ApiModelProperty()
    @Column()
    shop_code:string

    @ApiModelProperty()
    @Column()
    password:string

    @ApiModelPropertyOptional()
    @Column({nullable:true})
    device_token?:string

    constructor(partial: Partial<ShopUser>) {
        super()
        Object.assign(this, partial);
    }
}