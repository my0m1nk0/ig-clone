import { ApiModelProperty, ApiModelPropertyOptional } from "@nestjs/swagger";
import { IsNotEmpty, IsString, IsEnum } from "class-validator";
import { Role } from "../../admin/model/role.enum";
import { EnumToArray } from "../../shared/utilities/enum-to-array";

export class ShopUserDto {

    @ApiModelProperty()
    @IsNotEmpty()
    username:string

    @ApiModelProperty()
    @IsNotEmpty()
    phone:string 

    @ApiModelProperty()
    @IsNotEmpty()
    gmail :string

    @ApiModelProperty({default:Role.SHOP_CASHER,enum:EnumToArray(Role)})
    @IsEnum(Role)
    account_type:string

    @ApiModelPropertyOptional()
    shop_id ?:number

    @ApiModelPropertyOptional()
    shop_code ?:string

    @ApiModelPropertyOptional()
    password ?:string
}

export class CreateShopUser{
    @ApiModelProperty()
    @IsNotEmpty()
    username:string

    @ApiModelProperty()
    @IsNotEmpty()
    phone:string 

    @ApiModelProperty()
    @IsNotEmpty()
    gmail :string

    @ApiModelProperty({default:Role.SHOP_CASHER,enum:EnumToArray(Role)})
    @IsEnum(Role)
    account_type:string

    @ApiModelPropertyOptional()
    shop_id ?:number

    @ApiModelPropertyOptional()
    shop_code ?:string

    @ApiModelProperty()
    @IsNotEmpty()
    password :string
}