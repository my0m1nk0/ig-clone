import { Injectable, HttpStatus, HttpException, forwardRef, Inject } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { ShopUser } from './model/shop-user.entity';
import { Repository, Not, Equal } from 'typeorm';
import { ShopUserDto } from './model/shop-user.dto';
import { hash, compare } from 'bcryptjs';
import { LoginDto } from '../admin/model/login.dto';
import { AdminLoginVm } from '../admin/model/admin-login.vm';
import { AuthService } from '../shared/auth/auth.service';
import { Role } from '../admin/model/role.enum';
import { ShopLicenseService } from 'src/shop-license/shop-license.service';

@Injectable()
export class ShopUserService {
    constructor(
        @InjectRepository(ShopUser) private readonly _shopUser:Repository<ShopUser>,
        @Inject(forwardRef(() => ShopLicenseService)) readonly _shopLicenseService: ShopLicenseService,
        private readonly _authService:AuthService,
        ){
    }

    async getAll(limit:number,skip:number,shop:number,user_role:Role){
        try {
            let filterShop = shop ? {shop_id:shop} : {}
            let filterRole = user_role ? {account_type:user_role} : {}
            let data = await this._shopUser.find({ where: {...filterShop,...filterRole},skip:skip,take:limit,order:{id:-1}});
            return data
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);  
        } 
    }

    async loginUser(data:LoginDto){
        let response = new AdminLoginVm()
        let shop = await this._shopUser.find({username:data.username})
        if(shop.length == 0)
            throw new HttpException("Username is Invalid!", HttpStatus.BAD_REQUEST);

        let comfirm = await compare(data.password,shop[0].password)
        if(!comfirm)
            throw new HttpException("Wrong Password", HttpStatus.BAD_REQUEST);

        response.token = await this._authService.generateToken(shop[0].id,shop[0].account_type)
        response.user = shop[0]
        
        return response
    }

    async createShopUser(data:ShopUserDto,newUser:boolean=false){
        let shopUsers = await this.checkExist(data.username,data.phone)
        if(shopUsers.length > 0)
            throw new HttpException("User Name is Already Created !", HttpStatus.BAD_REQUEST);
            let shopLicense = await this._shopLicenseService.checkExpire(data.shop_id)
            let userCount = await this._shopUser.count({shop_id:data.shop_id})
        if(newUser != true){
            if(shopLicense[0].no_of_user <= userCount)
                    throw new HttpException("You have reach your package limitation !", HttpStatus.BAD_REQUEST);
        }
        try {
            let newShopUser = new ShopUser(data)
            newShopUser.password = await hash(data.password,10)
            return await this._shopUser.save(newShopUser)
            return {"message":"Created New Shop User!"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async checkExist(username:string,phone:string,id:number=0){
        return await this._shopUser.find(
            {where:[
                {username:username,id:Not(Equal(id))},
                {phone:phone,id:Not(Equal(id))}
            ]} )
    }
    async getUser(id:string | number){
        return this._shopUser.findOne(id)
    }

    async updateShopUser(data:ShopUserDto,id:number){
        let shopUsers = await this.checkExist(data.username,data.phone,id)
        if(shopUsers.length > 0)
            throw new HttpException("Shop name is Already Exist !", HttpStatus.BAD_REQUEST);
        try{
            let shopUser = await this._shopUser.findOne(id)
            shopUser.username = data.username
            shopUser.phone = data.phone
            shopUser.gmail = data.gmail
            // shopUser.shop_code = data.shop_code
            if(shopUser.account_type != Role.SHOP_OWNER)
            shopUser.account_type = data.account_type
            // shopUser.shop_id = data.shop_id
            return await this._shopUser.save(shopUser)
            return {"message":"Updated Shop User !"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async changePassword(newPassword:string,id:number){
        try{
            let user = await this._shopUser.findOne(id)
            user.password = await hash(newPassword,10)
            await this._shopUser.save(user)
            return {"message":"Updated Shop User Passsword !"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async deleteShopUser(id:number){
        try{
            let packAge =  await this._shopUser.findOne(id)
            await this._shopUser.remove(packAge)
            return {"message":"Deleted Shop User!"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async updateDevice(id,device_token){
        let shop = await this._shopUser.findOne(id)
        shop.device_token = device_token
        return await this._shopUser.save(shop)
    }

    async getToken(shopId:number){
        return await this._shopUser.find({where:[{account_type:Role.SHOP_MANAGER,shop_id:shopId},{account_type:Role.SHOP_OWNER,shop_id:shopId}]})
    }
}
