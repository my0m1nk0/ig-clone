import { Module } from '@nestjs/common';
import { PusherNotiService } from './pusher-noti.service';

@Module({
  providers: [PusherNotiService]
})
export class PusherNotiModule {}
