export class NotiMessage{
    title:string
    body:string
}