import { Injectable } from '@nestjs/common';
import * as PushNotifications from '@pusher/push-notifications-server';
import { NotiMessage } from './noti-message';
@Injectable()
export class PusherNotiService {
    newPusher:any 
    constructor(){
        // let key = process.env.S3_BUCKET+'' || get(Configuration.S3_BUCKET)+''
        this.newPusher = new PushNotifications({
            instanceId: '2bba7c99-aacc-4c08-998b-d8ce322d35e3',
            secretKey: 'FB89C84CB1D34DCF2FD6979DE235F435D15DA41BA660121A2A73FF60D67B56B4'
          });
    }

    sendAllUser(usersToken:any[],message:NotiMessage){
        this.newPusher.publishToUsers(usersToken, {
            apns: {
              aps: {
                alert: message.title
              }
            },
            fcm: {
              notification: {
                title: message.title,
                body: message.body
              }
            }
          }).then((publishResponse) => {
            console.log('Just published:', publishResponse.publishId);
          }).catch((error) => {
            console.error('Error:', error);
          });
    }
}
