import { Controller, Get, HttpStatus, UsePipes, Query, Post, Body, Param, Put, Delete } from '@nestjs/common';
import { ApiResponse, ApiUseTags, ApiOperation, ApiImplicitQuery } from '@nestjs/swagger';
import { RequestLicense } from './model/request-license.entity';
import { RequestLicenseService } from './request-license.service';
import { ApiError } from 'src/shared/api-error.model';
import { ValidationPipe } from 'src/shared/validation.pipe';
import { getOperation } from 'src/shared/utilities/get-operation';
import { ParseIntPipe } from 'src/shared/parse-int.pipe';
import { ShopLicenseDto, ActiveStatus } from 'src/shop-license/model/shop-license.dto';
import { SuccessMessage } from 'src/shared/filters/success.vm';
const modelName = "Request License"

@Controller('shops/request-license')
@ApiUseTags(modelName)
@UsePipes(new ValidationPipe())
export class RequestLicenseController {
    constructor(private readonly _requestLicenseService:RequestLicenseService){}

    @Get()
    @ApiResponse({ status: HttpStatus.OK,type:RequestLicense,isArray:true})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Get Request Shop License'))
    @ApiImplicitQuery({name:'skip',type:Number,required:true})
    @ApiImplicitQuery({name:'limit',type:Number,required:true})
    @ApiImplicitQuery({name:'shop',type:Number,required:true})
    @ApiImplicitQuery({name:'packAge',type:Number,required:false})
    async getAll(
        @Query('skip',new ParseIntPipe()) skip:number,
        @Query('limit',new ParseIntPipe()) limit:number=null,
        @Query('shop') shop?:string,
        @Query('packAge') packAge?:string
        ){
        return await this._requestLicenseService.getAll(limit,skip,shop,packAge)
    }

    @Post()
    @ApiResponse({ status: HttpStatus.CREATED,type:RequestLicense})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Create Shop License'))
    async create(@Body() data:ShopLicenseDto){
        return this._requestLicenseService.createRequestLicense(data)
    }

    @Put(':id')
    @ApiResponse({ status: HttpStatus.OK,type:RequestLicense})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Update Shop License'))
    async update(@Body() data:ShopLicenseDto,@Param('id',new ParseIntPipe()) id:number ){
        return this._requestLicenseService.updateRequestLicense(data,id)
    }

    @Delete(':id')
    @ApiResponse({ status: HttpStatus.OK,type:SuccessMessage})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Delete Shop License'))
    async delete(@Param('id',new ParseIntPipe()) id:number){
        return this._requestLicenseService.deleteShopLicense(id)
        // return true
    }

    @Put('confirm/:id')
    @ApiResponse({ status: HttpStatus.OK,type:RequestLicense})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Update Shop License'))
    async updateActive(@Param('id',new ParseIntPipe()) id:number ){
        return this._requestLicenseService.confirmStatus(id)
    }
}
