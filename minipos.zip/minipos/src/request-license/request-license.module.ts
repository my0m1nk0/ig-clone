import { Module, forwardRef } from '@nestjs/common';
import { RequestLicenseController } from './request-license.controller';
import { RequestLicenseService } from './request-license.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RequestLicense } from './model/request-license.entity';
import { PackageModule } from 'src/package/package.module';
import { ShopLicenseModule } from 'src/shop-license/shop-license.module';
import { NotiModule } from 'src/noti/noti.module';
import { ShopUserModule } from 'src/shop-user/shop-user.module';
import { AdminModule } from 'src/admin/admin.module';
import { SendedNotiModule } from 'src/sended-noti/sended-noti.module';
import { ShopModule } from 'src/shop/shop.module';

@Module({
  imports:[
    TypeOrmModule.forFeature([RequestLicense]),
    forwardRef(() => PackageModule),
    forwardRef(() => ShopLicenseModule),
    forwardRef(() => NotiModule),
    forwardRef(() => ShopUserModule),
    forwardRef(() => AdminModule),
    forwardRef(() => ShopModule),
    forwardRef(() => SendedNotiModule),
  ],
  providers: [RequestLicenseService],
  controllers: [RequestLicenseController],
  exports : [RequestLicenseService]
})
export class RequestLicenseModule {}
