import { BaseModel } from "../../shared/base.model";
import { ApiModelProperty } from "@nestjs/swagger";
import { Column, Entity } from "typeorm";

@Entity()
export class RequestLicense extends BaseModel{

    @ApiModelProperty()
    @Column()
    shop_id:number

    @ApiModelProperty()
    @Column()
    package_id:number

    @ApiModelProperty()
    @Column()
    package_name:string

    @ApiModelProperty()
    @Column()
    amount:number

    @ApiModelProperty()
    @Column({default:0})
    discount:number

    @ApiModelProperty()
    @Column()
    price_per_month:number

    @ApiModelProperty()
    @Column()
    no_of_user:number

    @ApiModelProperty()
    @Column()
    no_of_stock:number

    @ApiModelProperty()
    @Column()
    no_of_month:number

    @ApiModelProperty()
    @Column({type:'bigint',default:0})
    start_date:number

    @ApiModelProperty()
    @Column({type:'bigint'})
    expire_date:number

    @ApiModelProperty()
    @Column({default:false})
    status:boolean

    constructor(partial: Partial<RequestLicense>) {
        super()
        Object.assign(this, partial);
    }
}