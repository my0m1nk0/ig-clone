import { Injectable, Inject, forwardRef, HttpException, HttpStatus } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, MoreThan } from 'typeorm';
import { RequestLicense } from './model/request-license.entity';
import { PackageService } from 'src/package/package.service';
import { ShopLicenseDto, ActiveStatus } from 'src/shop-license/model/shop-license.dto';
import { ShopLicenseService } from 'src/shop-license/shop-license.service';
import { NotiService } from 'src/noti/noti.service';
import { ShopUserService } from 'src/shop-user/shop-user.service';
import { AdminService } from 'src/admin/admin.service';
import { NotiDto } from 'src/sended-noti/model/noti.dto';
import { NotiMessageDto } from 'src/noti/model/noti.dto';
import { ShopService } from 'src/shop/shop.service';
import { SendedNotiService } from 'src/sended-noti/sended-noti.service';

@Injectable()
export class RequestLicenseService {
    constructor(
        @InjectRepository(RequestLicense) private readonly _requestLicense:Repository<RequestLicense>,
        @Inject(forwardRef(() => PackageService)) readonly _packageService: PackageService,
        @Inject(forwardRef(() => ShopLicenseService)) readonly _shopLicenseService: ShopLicenseService,
        @Inject(forwardRef(() => NotiService)) readonly _notiService: NotiService,
        @Inject(forwardRef(() => ShopUserService)) readonly _shopUser: ShopUserService,
        @Inject(forwardRef(() => AdminService)) readonly _adminService: AdminService,
        @Inject(forwardRef(() => ShopService)) readonly _shopService: ShopService,
        @Inject(forwardRef(() => SendedNotiService)) readonly _sendNotiService: SendedNotiService,
        ){
    }

    async getAll(limit:number,skip:number,shop:string,packAge:string){
        try {
            let filterShop = shop ? {shop_id:shop} : {}
            let filterPackAge = packAge ? {package_id:packAge} : {} 
            let data = await this._requestLicense.find({where:{...filterShop,...filterPackAge},skip:skip,take:limit,order:{status:-1,id:-1}});
            return data
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);  
        } 
    }

    async createRequestLicense(data:ShopLicenseDto){
        // let shopUsers = await this.checkExist(data.shop_id)
        // if(shopUsers.length > 0)
        //     throw new HttpException("Can't new License.Shop has been License,Please Upgrade License !", HttpStatus.BAD_REQUEST);
        try {
           let date = new Date(data.start_date)
           let packAge = await this._packageService.getDetail(data.package_id)
           let newLicense = new RequestLicense({package_name:packAge.name, price_per_month:packAge.price_per_month, no_of_user:packAge.no_of_user, no_of_stock:packAge.no_of_stock,shop_id:data.shop_id,package_id:packAge.id})
           newLicense.discount = 0
           newLicense.amount = data.no_of_month * packAge.price_per_month
           newLicense.no_of_month = data.no_of_month
           newLicense.start_date =new Date(data.start_date).getTime()
           newLicense.expire_date = new Date(date.setMonth(date.getMonth()+newLicense.no_of_month)).getTime()
           let license = await this._requestLicense.save(newLicense)
           await this.sendNotiToAdmin(data,packAge.name)
           return license
            // return this._shopLicense.create(newLicense)
            // return {"message":"Created New Shop License!"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async sendNotiToAdmin(data:ShopLicenseDto,packageName:string){
        let admins = await this._adminService.findAndGetToken()
        let tokens = admins.map(x=>{
            if(x.device_token !== "")
            return x.device_token
        })
        let shop = await this._shopService.getById(data.shop_id)
        let message = new NotiMessageDto()
        message.title = "Request License"
        message.body = {shop:data.shop_id,message:`Shop ${shop.name} was requested to buy a package ${packageName} ${data.no_of_month} months`}
        if(tokens.length > 0){
            await this._notiService.sendNoti(message,tokens)
            for(let admin of admins){
                let noti = new NotiDto()
                noti.message = JSON.stringify(message.body)
                noti.title = message.title
                noti.to = admin.id
                noti.type_client = false
                await this._sendNotiService.createNoti(noti)
            }
        }
    }

    async sendNotiToClient(shopId){
        let message = new NotiMessageDto()
        message.title = "Confirmed License from Admin"
        message.body = {shop:shopId,message:`Your purchase is successs`}
        let users = await this._shopUser.getToken(shopId)
        let tokens = users.map(x=>{
            if(x.device_token !== "")
            return x.device_token
        })
        if(tokens.length > 0){
            this._notiService.sendNoti(message,tokens)
            for(let user of users){
                let noti = new NotiDto()
                noti.message = JSON.stringify(message.body)
                noti.title = message.title
                noti.to = user.id
                noti.shop = user.shop_id
                noti.type_client = true
                await this._sendNotiService.createNoti(noti)
            }
        }
    }

    async checkExist(shopId:number){
        let nowData = new Date().getTime()
        return await this._requestLicense.find(
            {where: {shop_id:shopId,expire_date:MoreThan(nowData)} } 
        )
    }

    async updateRequestLicense(data:ShopLicenseDto,id:number){
        try{
            let requestLicense = await this._requestLicense.findOne(id)
            let date = new Date(requestLicense.start_date)
            requestLicense.no_of_month = data.no_of_month
            requestLicense.expire_date = date.setMonth(date.getMonth()+requestLicense.no_of_month)
            return await this._requestLicense.save(requestLicense)
            // return {"message":"Updated Shop License !"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async confirmStatus(id:number){
        let license = await this._requestLicense.findOne(id)
        if(license.status == true)
            throw new HttpException("License Was Confirmed", HttpStatus.BAD_REQUEST);
        try{
            let shopLicense = new ShopLicenseDto()
            shopLicense.package_id = license.package_id
            shopLicense.shop_id = license.shop_id
            shopLicense.start_date = parseInt(license.start_date+'')
            shopLicense.no_of_month = license.no_of_month
            let newLicense = await this._shopLicenseService.createShopLicense(shopLicense)
            let data = new ActiveStatus()
            data.active_status = true
            await this._shopLicenseService.updateActiveStatus(data,newLicense.id)
            license.status = true
            await this._requestLicense.save(license)
            // shopLicense.active_status = data.active_status   
            // return await this._requestLicense.save(shopLicense)
            await this.sendNotiToClient(license.shop_id)
            return {"message":"Confirm Request Shop License !",data:newLicense}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async deleteShopLicense(id:number){
        try{
            let packAge =  await this._requestLicense.findOne(id)
            await this._requestLicense.remove(packAge)
            return {"message":"Deleted Request Shop License !"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

}
