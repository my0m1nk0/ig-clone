import { Controller, UsePipes, UseGuards, Get, Post, Put, HttpStatus, Body, Delete, Param, Query } from '@nestjs/common';
import { ApiUseTags, ApiBearerAuth, ApiResponse, ApiOperation, ApiImplicitBody, ApiImplicitQuery } from '@nestjs/swagger';
import { ValidationPipe } from '../shared/validation.pipe';
import { AuthGuard } from '../shared/guard/auth.guard';
import { SuccessMessage } from '../shared/filters/success.vm';
import { ApiError } from '../shared/api-error.model';
import { getOperation } from '../shared/utilities/get-operation';
import { UserD } from '../shared/auth/users.decorator';
import { ParseIntPipe } from '../shared/parse-int.pipe';
import { PackageService } from './package.service';
import { Package } from './model/package.entity';
import { PackageDto } from './model/package.dto';

const modelName = 'Package'

@ApiUseTags(modelName)
@UsePipes(new ValidationPipe())
@Controller('package')
export class PackageController {
    constructor(private readonly _package:PackageService){}

    @Get()
    @ApiResponse({ status: HttpStatus.OK,type:Package,isArray:true})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Get Package'))
    @ApiImplicitQuery({name:'skip',type:Number,required:true})
    @ApiImplicitQuery({name:'limit',type:Number,required:true})
    async getAll(@Query('skip',new ParseIntPipe()) skip:number,@Query('limit') limit:string=null){
        return await this._package.getAll(limit,skip)
    }

    @Post()
    @ApiBearerAuth()
    @UseGuards(new AuthGuard())
    @ApiResponse({ status: HttpStatus.CREATED,type:Package})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Create Package'))
    async create(@Body() data:PackageDto){
        return this._package.createPackage(data)
    }

    @Put(':id')
    @ApiBearerAuth()
    @UseGuards(new AuthGuard())
    @ApiResponse({ status: HttpStatus.OK,type:Package})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Update Package'))
    async update(@Body() data:PackageDto,@Param('id',new ParseIntPipe()) id:number ){
        return this._package.updatePackage(data,id)
    }

    @Delete(':id')
    @ApiBearerAuth()
    @UseGuards(new AuthGuard())
    @ApiResponse({ status: HttpStatus.OK,type:SuccessMessage})
    @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: ApiError })
    @ApiOperation(getOperation(modelName, 'Delete Package'))
    async delete(@Param('id',new ParseIntPipe()) id:number){
        return this._package.deletePackage(id)
    }
}
