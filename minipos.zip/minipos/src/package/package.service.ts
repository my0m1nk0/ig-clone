import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { Repository, Not, Equal } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { Package } from './model/package.entity';
import { PackageDto } from './model/package.dto';

@Injectable()
export class PackageService {
    constructor(
        @InjectRepository(Package) private readonly _package:Repository<Package>,
        ){
    }

    async getAll(limit:string,skip:number){
        try {
            let takeLimit = parseInt(limit) > 0 ? {take:parseInt(limit)} : {}
            let data = await this._package.find({skip:skip,...takeLimit,order:{id:-1}});
            return data
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);  
        } 
    }

    async createPackage(data:PackageDto){
        let packages = await this._package.find({where:{name:data.name}})
        if(packages.length > 0)
            throw new HttpException("Package is Already Created!", HttpStatus.BAD_REQUEST);
        try {
            let newPackage = new Package(data)
            return await this._package.save(newPackage)
            // return {"message":"Created New Package!"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async updatePackage(data:PackageDto,id:number){
        let packages = await this._package.find({where:{name:data.name,id:Not(Equal(id))}})
        if(packages.length > 0)
            throw new HttpException("Package name is Already Exist!", HttpStatus.BAD_REQUEST);
        try{
            let packAge = await this._package.findOne(id)
            packAge.name = data.name
            packAge.price_per_month = data.price_per_month
            packAge.no_of_stock = data.no_of_stock
            packAge.no_of_user = data.no_of_user
            packAge.description = data.description
            return await this._package.save(packAge)
            // return {"message":"Updated Package !"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async deletePackage(id:number){
        try{
            let packAge =  await this._package.findOne(id)
            await this._package.remove(packAge)
            return {"message":"Deleted Package !"}
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

    async getDetail(id){
        try{
            return await this._package.findOne(id)
        } catch (error) {
            throw new HttpException(error, HttpStatus.INTERNAL_SERVER_ERROR);            
        }
    }

}
