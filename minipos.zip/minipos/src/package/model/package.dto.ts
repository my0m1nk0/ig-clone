import { ApiModelProperty, ApiModelPropertyOptional } from "@nestjs/swagger";
import { IsString, IsNotEmpty } from "class-validator";

export class PackageDto {
    
    @ApiModelProperty()
    @IsString()
    name:string
    
    @ApiModelProperty()
    @IsNotEmpty()
    price_per_month:number

    @ApiModelProperty()
    @IsNotEmpty()
    no_of_user:number

    @ApiModelProperty()
    @IsNotEmpty()
    no_of_stock:number


    @ApiModelPropertyOptional()
    // @IsString()
    description?:string
}