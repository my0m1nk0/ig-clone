import { BaseModel } from "../../shared/base.model";
import { Entity, Column } from "typeorm";
import { ApiModelProperty, ApiModelPropertyOptional } from "@nestjs/swagger";

@Entity()
export class Package extends BaseModel {
    @ApiModelProperty()
    @Column({type:'varchar',unique:true})
    name:string

    @ApiModelProperty()
    @Column()
    price_per_month:number

    @ApiModelProperty()
    @Column()
    no_of_user:number

    @ApiModelProperty()
    @Column()
    no_of_stock:number

    @ApiModelPropertyOptional()
    @Column({type:'text',nullable:true})
    description?:string
    constructor(partial: Partial<Package>) {
        super()
        Object.assign(this, partial);
    }
}