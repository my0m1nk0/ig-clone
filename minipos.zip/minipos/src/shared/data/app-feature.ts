export class AppFeatures{
    public static APP_FEATURES = { 
        admin: ["Package_Configuration","Shop_Management"],
        shop:["Shop_Info_Configure","User_Management","Ordering_System","Reporting_System","Stock_Management","Shift_Management"],
        shop_cashier:["Ordering_System","Stock_Management"]
    }
}