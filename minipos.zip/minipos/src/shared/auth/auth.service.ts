import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { ConfigurationService } from '../configuration/configuration.service';
import { Configuration } from '../configuration/configuration.enum';
import { JwtPayload } from './jwt-payload';
import { sign, SignOptions } from 'jsonwebtoken';
import * as jwt from 'jsonwebtoken';
import { AuthVm } from './auth-vm.model';

@Injectable()
export class AuthService {
  private readonly jwtOption: SignOptions;
  private readonly jwtkey: string;

  constructor(
    // @InjectModel(WhiteList.modelName) private readonly _whitelistModel: ModelType<WhiteList>,
    private readonly _configurationService: ConfigurationService,
  ) {
    this.jwtkey = _configurationService.get(Configuration.JWT_KEY);
  }

  async signPayload(payload: JwtPayload): Promise<string> {
    return sign(payload, this.jwtkey, this.jwtOption);
  }

  async validPayload(payload: JwtPayload): Promise<any> {
    return;
  }

  async generateToken(id: number, role: any): Promise<string> {
    try {
      const jwtPayload: JwtPayload = {
        id: id,
        role: role,
        iat: new Date().getTime()
      };
      return await this.signPayload(jwtPayload);;
    } catch (error) {
      console.log('Error', error);
    }
  }

  async verify(auth: string): Promise<AuthVm> {
    if (auth.split(' ')[0] !== 'Bearer') {
      throw new HttpException('Invalid Token', HttpStatus.FORBIDDEN);
    }
    const token = auth.split(' ')[1];
    try {
      const decoded: AuthVm = (await jwt.verify(token, this.jwtkey)) as AuthVm;
      if (decoded) return decoded;
    } catch (err) {
      const message = 'Invalid Token' + (err.message || err.name);
    }
  }
}
