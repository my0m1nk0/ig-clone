
export class AuthVm{
    id: string
    role: string
}