import { createParamDecorator } from '@nestjs/common';

export const UserD = createParamDecorator((data, req) => {
  return data ? req.user[data] : req.user;
});
