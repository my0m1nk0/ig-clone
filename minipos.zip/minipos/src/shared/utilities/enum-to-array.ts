export function EnumToArray(enumData: any): string[] {
    return Object.keys(enumData).map(key=> enumData[key]);
}