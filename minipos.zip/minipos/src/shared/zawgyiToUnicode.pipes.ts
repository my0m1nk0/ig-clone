import { Injectable, PipeTransform } from '@nestjs/common';
import google_myanmar_tools = require('myanmar-tools');
@Injectable()
export class ZawgyiToUni implements PipeTransform {
  transform(body: any) {
    let text = JSON.stringify(body);

    if (!text || text == null) {
      return text;
    }
    try {
      const detector = new google_myanmar_tools.ZawgyiDetector();
      const converter = new google_myanmar_tools.ZawgyiConverter();
      const score = detector.getZawgyiProbability(text);
      let percentage = score * 100;
      if (percentage > 50) {
        text = converter.zawgyiToUnicode(text);
      }
      return JSON.parse(text);
    } catch (error) {
      console.warn('Warm', error.message);
    }
  }
}
