import { ApiModelPropertyOptional, ApiModelProperty } from '@nestjs/swagger';
import {  PrimaryGeneratedColumn,CreateDateColumn, UpdateDateColumn } from 'typeorm';

export abstract class BaseModel {
  @ApiModelProperty()
  @PrimaryGeneratedColumn() id: number;

  @ApiModelProperty()
  @CreateDateColumn()
  created_date: Date;

  @ApiModelPropertyOptional()
  @UpdateDateColumn()
  updated_date?: Date;
 
}
