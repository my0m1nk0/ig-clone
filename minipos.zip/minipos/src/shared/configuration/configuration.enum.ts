export enum Configuration {
    HOST = 'HOST',
    PORT = 'PORT',
    DB_URI = 'DB_URI',
    JWT_KEY = 'JWT_KEY',
    SMTP_URI = 'SMTP_URI',
    AWS_ACCESS_KEY = 'AWS_ACCESS_KEY',
    AWS_SECRET_KEY = 'AWS_SECRET_KEY',
    S3_BUCKET = 'S3_BUCKET',
    STARTCOUNT = 'STARTCOUNT',
    DB_PORT = 'DB_PORT',
    DB_USER = 'DB_USER',
    DB_PASS = 'DB_PASS',
    DB_NAME = 'DB_NAME',
    FIRE_BASE_KEY = 'FIRE_BASE_KEY'
  }
  