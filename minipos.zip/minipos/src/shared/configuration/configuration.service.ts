import { Injectable } from '@nestjs/common';
import { Configuration } from './configuration.enum';
import { get } from 'config';
@Injectable()
export class ConfigurationService {
  static configString: string =
    process.env[Configuration.DB_URI] || get(Configuration.DB_URI);
  private enviromentHosting: string = process.env.NODE_ENV || 'development';

  static emailTransport: string =
    process.env[Configuration.SMTP_URI] || get(Configuration.SMTP_URI);

  get(name: string): string {
    return process.env[name] || get(name);
  }

  get isDevelopment(): boolean {
    return this.enviromentHosting == 'development';
  }
}
