import { ApiModelProperty } from "@nestjs/swagger";

export class SuccessMessage{
    @ApiModelProperty()
    message:string
}