import {
    CanActivate,
    ExecutionContext,
    Injectable,
  } from '@nestjs/common';
  const google_myanmar_tools = require("myanmar-tools");
  @Injectable()
  export class UnicodeGuard implements CanActivate {
    async canActivate(context: ExecutionContext): Promise<any> {
      const request = context.switchToHttp().getRequest();
      request.body = await this.convertUnicode(request.body);
      return true;
    }
  
    async convertUnicode(body: string) {
        let text = JSON.stringify(body)

        if(!text|| text ==null){
            return text
        }
        try {
            const detector = new google_myanmar_tools.ZawgyiDetector();
            const converter = new google_myanmar_tools.ZawgyiConverter();
            const score = detector.getZawgyiProbability(text);
            let percentage = score * 100
            if(percentage >50){
                text = converter.zawgyiToUnicode(text)
            }
            return JSON.parse(text)            
        } catch (error) {
            console.warn("Warm",error.message)
        }      
    }
  }
  