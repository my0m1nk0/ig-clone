export enum DEVICE_OS{
    ANDROID='android',
    IOS="ios",
    WEB="web"
}