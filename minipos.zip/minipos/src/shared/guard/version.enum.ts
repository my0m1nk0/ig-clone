export enum Version{
    ANDROID_VERSION = "1.0.0",
    IOS_VERSION = "1.0.0"
}