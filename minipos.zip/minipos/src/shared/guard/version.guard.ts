import {
  CanActivate,
  ExecutionContext,
  Injectable,
  HttpStatus,
  HttpException,
} from '@nestjs/common';
import { DEVICE_OS } from './device_os.enum';
import { Version } from './version.enum';
@Injectable()
export class VersionGuard implements CanActivate {
  async canActivate(context: ExecutionContext): Promise<any> {
    const request = context.switchToHttp().getRequest();   
     this.compareAppVersionAndMinAppVersion(request.headers);
    return true;
  }

  compareAppVersionAndMinAppVersion(body) {
    let appVersion = body['accept-version'];
    let device_os: string = body['device-os'];

    if (!appVersion) {
      throw new HttpException(
        "App Version is Require",  HttpStatus.BAD_REQUEST,
      );
    }
  
    if (!device_os) {
      throw new HttpException(
        "Device Os is Require",
        HttpStatus.BAD_REQUEST,
      );
    } else if (!DEVICE_OS[device_os.toUpperCase()]) {
      throw new HttpException(
        "Invalide Device OS",
        HttpStatus.BAD_REQUEST,
      );
    }


    let AppVersionSpec = Version.ANDROID_VERSION;
    if (device_os == DEVICE_OS.ANDROID ) {
      AppVersionSpec = Version.ANDROID_VERSION;
    }
    if (device_os == DEVICE_OS.IOS ) {
      AppVersionSpec = Version.IOS_VERSION;
    }

    let validateCode = this.versionToVersionCode(appVersion);
    if (validateCode <= 0 || isNaN(validateCode)) {
      throw new HttpException(
        "Invalide app version",
        HttpStatus.BAD_REQUEST,
      );
    }

    if (validateCode < this.versionToVersionCode(AppVersionSpec)) {
      throw new HttpException('Please update your appliaction', 426);
    }
  }

  versionToVersionCode(version) {
    version = String(version).replace('.', '');
    return parseFloat(version);
  }
}
