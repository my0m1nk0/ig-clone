import { Module, Global } from '@nestjs/common';
import { ConfigurationService } from './configuration/configuration.service';
import { AuthService } from './auth/auth.service';
import { JwtStrategyService } from './strategy/jwt-strategy.service';
@Global()
@Module({
  imports: [],
  providers: [ConfigurationService,AuthService,JwtStrategyService],
  exports: [ConfigurationService,AuthService,JwtStrategyService],

})
export class SharedModule {}
