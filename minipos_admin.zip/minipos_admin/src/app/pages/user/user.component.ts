import { Component, OnInit } from "@angular/core";
import { JwtService } from 'src/app/shared/services/jwt.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { NgbModalRef, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { UserService } from './user.service';
import { AlertErrorService } from 'src/app/shared/services/alert-error.service';
import { Router } from '@angular/router';

@Component({
  selector: "app-user",
  templateUrl: "user.component.html"
})
export class UserComponent implements OnInit {
  showPassword:boolean = false
  user:any
  dataForm:FormGroup
  modalRef: NgbModalRef
  constructor(
    private readonly _router:Router,
    private readonly _jwtService:JwtService,
    private readonly _userService:UserService,
    private readonly _alert:AlertErrorService,
    private readonly _modalService: NgbModal) {}

  ngOnInit() {
    this.user = this._jwtService.getUser()
    if(!this.user){
      this._router.navigate(['/login']);
    }
  }

  setForm(){
    this.dataForm = new FormGroup({
      'password': new FormControl(null,[Validators.required]),
      'confirm_password': new FormControl(null,[Validators.required]),
    })
  }

  openModal(content){
    this.setForm()
    this.modalRef = this._modalService.open(content)
  }

  changeStatus(event){
    this.showPassword = event.target.checked
  }

  saveData(){
    let data = { password : this.dataForm.value.password }
    let path = this.user.account_type == 'admin' ? "admin/password/" : "shops/shop-user/password/"
    this.modalRef.close()
    this._userService.changePassword(path+this.user.id,data).subscribe(res=>{
      this._alert.alertUpdatemessage()
    },error=>this._alert.alertError(error))
  }
}
