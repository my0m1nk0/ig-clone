import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { UserComponent } from './user.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { UserService } from './user.service';

const routes: Routes = [
  {
    path: '',
    data: {
      title: 'User Profile Page',
      urls: [
        { title: 'User Profile', url: '/profile' },
        { title: 'User Profile Page' }
      ]
    },
    component: UserComponent
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    NgbModule.forRoot(),
  ],
  declarations: [UserComponent],
  providers:[UserService]
})
export class UserModule {}
