import { Injectable } from '@angular/core';
import { ServerService } from 'src/app/shared/services/server.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor(private readonly _server: ServerService) { }

  changePassword(path,data):Observable<any>{
    return this._server.put(path,data)
  }
}