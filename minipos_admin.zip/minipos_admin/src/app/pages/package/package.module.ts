import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PackageComponent } from './package.component';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PackageService } from './package.service';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Package Configuration',
      urls: [
        { title: 'Package Configuration', url: '/package_configuration' },
        { title: 'Package Configuration' }
      ]
    },
    component: PackageComponent
  }
];

@NgModule({
  declarations: [PackageComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    NgbModule.forRoot(),
  ],
  providers: [ PackageService ]
})
export class PackageModule { }
