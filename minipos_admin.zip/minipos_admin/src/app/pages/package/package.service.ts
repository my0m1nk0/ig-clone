import { Injectable } from '@angular/core';
import { ServerService } from 'src/app/shared/services/server.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PackageService {
  path = 'package'
  constructor(private readonly _server: ServerService) { }

  getData(skip:number,limit:number): Observable<any>{
    let url = `${this.path}?skip=${skip}&limit=${limit}`
    return this._server.get(url)
  }

  addData(data:any): Observable<any>{
    return this._server.post(this.path,data)
  }
  updateData(data:any,id:number):Observable<any>{
    let url = `${this.path}/${id}`
    return this._server.put(url,data)
  }

  deleteData(id){
    return this._server.delete(`${this.path}/${id}`)
  }
}
