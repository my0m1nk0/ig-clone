import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { NgbModalRef, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AlertErrorService } from 'src/app/shared/services/alert-error.service';
import { PackageService } from './package.service';

@Component({
  selector: 'app-package',
  templateUrl: './package.component.html',
  styleUrls: ['./package.component.scss']
})
export class PackageComponent implements OnInit,OnDestroy {

  viewDataArray:any[] = []
  editKey:number = -1
  page:number = 1
  dataForm:FormGroup
  modalRef: NgbModalRef
  dataloaing:boolean = false
  modalTitle:string
  constructor(
    private readonly _packageService:PackageService,
    private readonly _alert:AlertErrorService,
    private readonly _modalService: NgbModal
  ) { }

  ngOnInit() {
    this.getData(0)
  }

  ngOnDestroy(){
    this.viewDataArray = []
    this.page = 0
    this.editKey = -1
  }

  getData(page){
    this.page = page
    let limit = 5
    let skip = page * 5
    this._packageService.getData(skip,limit).subscribe(res=>{
      if(res.length > 0)
        this.viewDataArray = this.viewDataArray.concat(res)
      else {
        alert("No More Data")
        this.page -= 1
      }
      },error=>this._alert.alertError(error))
  }

  setForm(){
    let name = this.editKey < 0 ? "" : this.viewDataArray[this.editKey].name
    let price_per_month = this.editKey < 0 ? "" : this.viewDataArray[this.editKey].price_per_month
    let no_of_user = this.editKey < 0 ? "" : this.viewDataArray[this.editKey].no_of_user
    let no_of_stock = this.editKey < 0 ? "" : this.viewDataArray[this.editKey].no_of_stock
    this.dataForm = new FormGroup({
      'name': new FormControl(name,[Validators.required]),
      'price_per_month': new FormControl(price_per_month,[Validators.required,Validators.min(1)]),
      'no_of_user': new FormControl(no_of_user,[Validators.required,Validators.min(1)]),
      'no_of_stock': new FormControl(no_of_stock,[Validators.required,Validators.min(1)]),
    })
  }

  openModal(key:number,content){
    this.editKey = key
    this.setForm()
    this.modalTitle = key < 0 ? "Add New Package" : "Edit Package"
    // { size: 'sm' }
    this.modalRef = this._modalService.open(content)
  }

  saveData():void{
    this.modalRef.close()
    this.editKey < 0 ? this.addData() : this.updatedata()
  }

  addData(){
    let data = this.dataForm.value
    
    this._packageService.addData(data).subscribe(res=>{
      this.viewDataArray.unshift(res)
      this._alert.alertAddmessage()
    },error=>this._alert.alertError(error))
  }

  updatedata(){
    let data = this.dataForm.value
    let id = this.viewDataArray[this.editKey].id
    this._packageService.updateData(data,id).subscribe(res=>{
      this.viewDataArray[this.editKey] = {id:this.viewDataArray[this.editKey].id,...data}
      this._alert.alertUpdatemessage()
    },error=>this._alert.alertError(error))
  }

  deleteData(id){
    this._packageService.deleteData(id).subscribe(res=>{
      let indexKey = this.viewDataArray.findIndex(x=>x.id==id)
      this.viewDataArray.splice(indexKey,1)
    },error=>this._alert.alertError(error))
  }
}
