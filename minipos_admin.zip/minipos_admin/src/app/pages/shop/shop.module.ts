import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShopComponent } from './shop.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { ShopService } from './shop.service';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { PackageService } from '../package/package.service';

const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Shop Management',
      urls: [
        { title: 'Shop Management', url: '/shop_management' },
        { title: 'Shop Management' }
      ]
    },
    component: ShopComponent
  }
];

@NgModule({
  declarations: [ShopComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    NgbModule.forRoot(),
  ],
  providers: [ShopService,PackageService ]
})
export class ShopModule { }
