import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { NgbModalRef, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ShopService } from './shop.service';
import { AlertErrorService } from 'src/app/shared/services/alert-error.service';
import { PackageService } from '../package/package.service';
import { AwsService } from 'src/app/shared/services/aws.service';
import { ShareDataService } from 'src/app/shared/services/share-data.service';

@Component({
  selector: 'app-shop',
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.scss']
})
export class ShopComponent implements OnInit,OnDestroy {
  defaultImage:string = "assets/img/no-image.jpg"
  viewDataArray:any[] = []
  packageDataArray:any[] = []
  packageId:number
  editKey:number = -1
  page:number = 1
  dataForm:FormGroup
  modalRef: NgbModalRef
  dataloaing:boolean = false
  modalTitle:string
  imageUrl:string = ""
  constructor(
    private readonly _packageService:PackageService,
    private readonly _shopService:ShopService,
    private readonly _alert:AlertErrorService,
    private readonly _modalService: NgbModal,
    private readonly _aws: AwsService,
    private readonly _shareDataService:ShareDataService
  ) { }

  ngOnInit() {
    this.getData(0)
    this.getPackAge()
  }

  ngOnDestroy(){
    this.viewDataArray = []
    this.page = 0
    this.editKey = -1
  }

  getPackAge(){
    this._packageService.getData(0,null).subscribe(res=>{
      this.packageDataArray = res
    },error=>this._alert.alertError(error))
  }

  getData(page){
    this.page = page
    let limit = 5
    let skip = page * 5
    this._shopService.getData(skip,limit).subscribe(res=>{
      if(res.length > 0)
        this.viewDataArray = this.viewDataArray.concat(res)
      else {
        alert("No More Data")
        this.page -= 1
      }
    },error=>this._alert.alertError(error))
  }
  // name
  // phone
  // gmail
  // logo
  // tax
  // service_charges
  // address
  setForm(){
    
    this.imageUrl = this.editKey < 0 ? "" : this.viewDataArray[this.editKey].logo_url
    let name = this.editKey < 0 ? "" : this.viewDataArray[this.editKey].name
    let phone = this.editKey < 0 ? "" : this.viewDataArray[this.editKey].phone
    let gmail = this.editKey < 0 ? "" : this.viewDataArray[this.editKey].gmail
    let logo = this.editKey < 0 ? "abc" : this.viewDataArray[this.editKey].logo
    let tax = this.editKey < 0 ? 0 : this.viewDataArray[this.editKey].tax
    let service_charges = this.editKey < 0 ? 0 : this.viewDataArray[this.editKey].service_charges
    let address = this.editKey < 0 ? "" : this.viewDataArray[this.editKey].address
    this.dataForm = new FormGroup({
      'name': new FormControl(name,[Validators.required]),
      'phone': new FormControl(phone,[Validators.required]),
      'gmail': new FormControl(gmail,),
      'logo': new FormControl(logo,[Validators.required]),
      'tax': new FormControl(tax,[Validators.required]),
      'service_charges': new FormControl(service_charges,[Validators.required]),
      'address': new FormControl(address,[Validators.required]),
    })
    if(this.editKey < 0){
      this.dataForm.addControl('package_id',new FormControl('',Validators.required))
      this.dataForm.addControl('no_month',new FormControl(1,[Validators.required,Validators.min(1)]))
    }
  }

  openModal(key:number,content){
    this.editKey = key
    this.setForm()
    this.modalTitle = key < 0 ? "Add New Shop" : "Edit Shop"
    // { size: 'sm' }
    this.modalRef = this._modalService.open(content,{ size: 'lg' })
  }

  saveData():void{
    this.modalRef.close()
    this.editKey < 0 ? this.addData() : this.updatedata()
  }

  addData(){
    let data = this.dataForm.value
    data.package_id = this.packageDataArray[data.package_id].id
    this._shopService.addData(data).subscribe(res=>{
      this.viewDataArray.unshift(res)
      this._alert.alertAddmessage()
    },error=>this._alert.alertError(error))
  }

  updatedata(){
    let data = this.dataForm.value
    let id = this.viewDataArray[this.editKey].id
    this._shopService.updateData(data,id).subscribe(res=>{
      this.viewDataArray[this.editKey] = res
      this._alert.alertUpdatemessage()
    },error=>this._alert.alertError(error))
  }

  deleteData(id){
    this._shopService.deleteData(id).subscribe(res=>{
      let indexKey = this.viewDataArray.findIndex(x=>x.id==id)
      this.viewDataArray.splice(indexKey,1)
    },error=>this._alert.alertError(error))
  }

  async handleInput(file: FileList) {
    let img_file = file.item(0);
    if(img_file.type.indexOf("image") >= 0 ){
      let reader = new FileReader();
      reader.onload = (event: any) => {
        this.imageUrl = event.target.result;
      }
      reader.readAsDataURL(img_file);
      let photo = await this._aws.uploadProfie(img_file)
      console.log(photo)
      this.dataForm.controls['logo'].setValue(`${photo.image}`)
    }
  }

  async viewLicense(shopId){
    this._shareDataService.setShopId(shopId)
  }
}
