import { Injectable } from '@angular/core';
import { ServerService } from 'src/app/shared/services/server.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ShopService {
  path = 'shop'
  constructor(private readonly _server: ServerService) { }

  getData(skip:number,limit:number): Observable<any>{
    let url = `${this.path}?skip=${skip}&limit=${limit}`
    return this._server.get(url)
  }

  addData(data:any): Observable<any>{
    let url = `${this.path}?package_id=${data.package_id}&no_month=${data.no_month}`
    delete data.package_id
    delete data.no_month
    return this._server.post(url,data)
  }
  updateData(data:any,id:number):Observable<any>{
    let url = `${this.path}/${id}`
    return this._server.put(url,data)
  }

  deleteData(id){
    return this._server.delete(`${this.path}/${id}`)
  }
}
