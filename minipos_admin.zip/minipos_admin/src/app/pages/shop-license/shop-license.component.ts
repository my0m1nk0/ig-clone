import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { NgbModalRef, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { PackageService } from '../package/package.service';
import { AlertErrorService } from 'src/app/shared/services/alert-error.service';
import { ShareDataService } from 'src/app/shared/services/share-data.service';
import { Router } from '@angular/router';
import { ShopLicenseService } from './shop-license.service';

@Component({
  selector: 'app-shop-license',
  templateUrl: './shop-license.component.html',
  styleUrls: ['./shop-license.component.scss']
})
export class ShopLicenseComponent implements OnInit,OnDestroy {

  viewDataArray:any[] = []
  editKey:number = -1
  page:number = 1
  dataForm:FormGroup
  modalRef: NgbModalRef
  dataloaing:boolean = false
  modalTitle:string
  packageDataArray:any[] = []
  packageId:number
  shopId:number
  constructor(
    private readonly _shopLicenseService:ShopLicenseService,
    private readonly _packageService:PackageService,
    private readonly _alert:AlertErrorService,
    private readonly _modalService: NgbModal,
    private readonly _shareDataService:ShareDataService,
    private readonly _router:Router
  ) { }

  ngOnInit() {
    
    this.shopId = this._shareDataService.getShopId()
    this.setForm()
    if(this.shopId < 1)
      this._router.navigate(['/shop_management'])
    else{
      this.getPackAge()
      this.getData(0)
    }
  }
  ngOnDestroy(){
    this.viewDataArray = []
    this.page = 0
    this.editKey = -1
  }
  getPackAge(){
    this._packageService.getData(0,null).subscribe(res=>{
      this.packageDataArray = res
    },error=>this._alert.alertError(error))
  }

  getData(page){
    this.page = page
    let limit = 5
    let skip = page * 5
    this._shopLicenseService.getData(skip,limit,this.shopId).subscribe(res=>{
      console.log(res)
      if(res.length > 0)
        this.viewDataArray = this.viewDataArray.concat(res)
      else {
        alert("No More Data")
        this.page -= 1
      }
      },error=>this._alert.alertError(error))
  }

  setForm(){
    this.dataForm = new FormGroup({
      'shop_id': new FormControl(this.shopId,[Validators.required]),
      'package_id': new FormControl('',[Validators.required]),
      'no_of_month': new FormControl(1,[Validators.required,Validators.min(1)]),
    })
  }

  saveData():void{
    this.editKey < 0 ? this.addData() : ""
  }

  addData(){
    let data = this.dataForm.value
    data.package_id = this.packageDataArray[data.package_id].id
    this._shopLicenseService.addData(data).subscribe(res=>{
      this.viewDataArray.unshift(res)
      this._alert.alertAddmessage()
    },error=>this._alert.alertError(error))
    this.setForm()
  }

  // updatedata(){
  //   let data = this.dataForm.value
  //   let id = this.viewDataArray[this.editKey].id
  //   this._shopLicenseService.updateData(data,id).subscribe(res=>{
  //     this.viewDataArray[this.editKey] = {id:this.viewDataArray[this.editKey].id,...data}
  //     this.modalRef.close()
  //     this._alert.alertUpdatemessage()
  //   },error=>this._alert.alertError(error))
  // }

}
