import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShopLicenseComponent } from './shop-license.component';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ShopLicenseService } from './shop-license.service';
import { PackageService } from '../package/package.service';

const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Package Configuration',
      urls: [
        { title: 'Package Configuration', url: '/package_configuration' },
        { title: 'Package Configuration' }
      ]
    },
    component: ShopLicenseComponent
  }
];

@NgModule({
  declarations: [ShopLicenseComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    NgbModule.forRoot(),
  ],
  providers: [ ShopLicenseService,PackageService ]
})
export class ShopLicenseModule { }
