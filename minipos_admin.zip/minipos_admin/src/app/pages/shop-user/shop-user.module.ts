import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShopUserComponent } from './shop-user.component';

@NgModule({
  declarations: [ShopUserComponent],
  imports: [
    CommonModule
  ]
})
export class ShopUserModule { }
