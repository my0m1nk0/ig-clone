import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { RouterModule } from "@angular/router";
import { ToastrModule } from 'ngx-toastr';

import { AppComponent } from "./app.component";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";

import { ComponentsModule } from "./components/components.module";
import { SpinnerComponent } from './shared/spinner.component';
import { AppRoutes } from './app-routing.module';
import { LocationStrategy, PathLocationStrategy } from '@angular/common';
import { HttpTokenInterceptor } from './shared/interceptor/http-token.interceptor';
import { ServerService } from './shared/services/server.service';
import { JwtService } from './shared/services/jwt.service';
import { AlertErrorService } from './shared/services/alert-error.service';
import { AwsService } from './shared/services/aws.service';
import { AuthGuard } from './shared/guard/auth.guard';
import { ShareDataService } from './shared/services/share-data.service';

@NgModule({
  imports: [
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    ComponentsModule,
    ReactiveFormsModule,
    FormsModule,
    NgbModule,
    RouterModule,
    RouterModule.forRoot(AppRoutes,{useHash:true}),
    ToastrModule.forRoot(),
  ],
  declarations: [AppComponent,SpinnerComponent],
  providers: [
    AuthGuard,
    {
      provide: LocationStrategy,
      useClass: PathLocationStrategy
    },
    { provide: HTTP_INTERCEPTORS, useClass: HttpTokenInterceptor, multi: true },
    ServerService,
    JwtService,
    AlertErrorService,
    AwsService,
    ShareDataService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
