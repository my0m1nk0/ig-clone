import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { LoginModel } from './login.model';
import { LoginService } from './login.service';
import { JwtService } from '../shared/services/jwt.service';
import { Router } from '@angular/router';
import { Role } from '../shared/role.enum';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm:FormGroup
  constructor(
    private readonly _loginService:LoginService,
    private readonly _jwtService:JwtService,
    private readonly _router:Router
    ) { 
    
  }

  ngOnInit() {
    this.setForm()
    if(this._jwtService.getToken()){
      let user = this._jwtService.getUser()
      if(user.account_type == Role.ADMIN)
        this._router.navigate(['/package_configuration'])
      else if( user.account_type == Role.SHOP_OWNER)
        this._router.navigate(['/profile'])
    }
  }

  setForm(){
    this.loginForm = new FormGroup({
      'username': new FormControl(null,Validators.required),
      'password': new FormControl(null,Validators.required)
    })
  }

  onLoggedin(){
    if(this.loginForm.invalid)
      return false
    let data = new LoginModel(this.loginForm.value)
    this._loginService.login(data).subscribe(async (res)=>{
      this._jwtService.saveToken(res.token)
      this._jwtService.setUser(res.user)
      let features = await this._loginService.getFeature()
      this._jwtService.setFeature(features)
      if(res.user.account_type == Role.ADMIN)
        this._router.navigate(['/package_configuration'])
      else if( res.user.account_type == Role.SHOP_OWNER)
        this._router.navigate(['/profile'])
    },error=>{
    })
  }

}
