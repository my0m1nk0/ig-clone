import { Injectable } from '@angular/core';
import { ServerService } from '../shared/services/server.service';
import { LoginModel } from './login.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  path = "admin/login"
  constructor(private readonly _serverService: ServerService) { }

  login(data:LoginModel):Observable<any>{
    return this._serverService.post(this.path,data)
  }

  async getFeature(){
    return this._serverService.awaitGet('features')
  }
}
