export class LoginModel{
    username:string
    password:string
    constructor(partial: Partial<LoginModel>) {
        Object.assign(this, partial);
    }
}