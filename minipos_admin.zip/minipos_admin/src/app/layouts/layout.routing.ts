import {  Routes } from "@angular/router";
import { AdminLayoutComponent } from './admin-layout/admin-layout.component';
import { AuthGuard } from '../shared/guard/auth.guard';
export const LayoutRoutes: Routes = [
    {
        path:'',component:AdminLayoutComponent,
        children:[
            {
                path : '',
                redirectTo : 'profile'
            },
            {
                path : 'profile',loadChildren:'../pages/user/user.module#UserModule',canActivate:[AuthGuard],
            },
            {
                path : 'shop_management',loadChildren:'../pages/shop/shop.module#ShopModule',canActivate:[AuthGuard],
            },
            {
                path : 'package_configuration',loadChildren:'../pages/package/package.module#PackageModule',canActivate:[AuthGuard],
            },
            {
                path : 'shop-license',loadChildren:'../pages/shop-license/shop-license.module#ShopLicenseModule',canActivate:[AuthGuard],
            },
            {
                path: 'notfound',loadChildren:'../pages/unauthorized/unauthorized.module#UnauthorizedModule',canActivate:[AuthGuard]
            }
        ]
    }
]