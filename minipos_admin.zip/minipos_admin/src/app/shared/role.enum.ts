export enum Role{
    ADMIN = 'admin',
    SHOP_OWNER = 'shop_owner',
    SHOP_MANAGER = 'shop_manager',
    SHOP_CASHER = 'shop_casher',
}