import { Injectable, Injector } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpParams } from '@angular/common/http';
import { JwtService } from '../services/jwt.service';
import { Observable } from 'rxjs';


@Injectable()
export class HttpTokenInterceptor implements HttpInterceptor {
  constructor(private jwtService: JwtService) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    
    if(req.headers.get("Content-Type") == "image/jpeg")
      return next.handle(req)
    const headersConfig = {
      'Content-Type':  'application/json',
      "Accept": "application/json",
      'Authorization':""
    };
    
    if (this.jwtService.getToken()) {
        headersConfig.Authorization = "Bearer " +this.jwtService.getToken();
    }

    const request = req.clone({ setHeaders: headersConfig});
    return next.handle(request);
  }

}
