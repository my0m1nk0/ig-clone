import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { JwtService } from '../services/jwt.service';

@Injectable()
export class AuthGuard implements CanActivate {

    constructor(private router: Router, private jwtService: JwtService,private activeRoute:ActivatedRoute) { }

    canActivate(next: ActivatedRouteSnapshot) {
        if (this.jwtService.getToken()) {
            let url = window.location.pathname
            let path = next.url.length > 0 ? next.url[0].path  : url.substring(1);
            if(path == "shop-license") path = 'shop_management';
            const permission = this.jwtService.getFeature();
            const access = permission.filter(x=> String(x.name).toLowerCase() == path )
            if( access.length > 0 || path == 'profile' || path == "notfound" ){
                return true;
            }
            else{
                this.router.navigate(['/notfound']);
                return false;
            }

        }
        this.router.navigate(['/login']);

        return true;

    }
}
