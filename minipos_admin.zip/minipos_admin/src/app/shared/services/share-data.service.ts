import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable()
export class ShareDataService {
    constructor(
        private readonly _router:Router
    ){}
    private shopId:number = 0

    setShopId(id:number){
        this.shopId = id
        this._router.navigate(['/shop-license'])
    }

    getShopId(){
        return this.shopId
    }
}