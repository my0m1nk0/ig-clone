import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AlertErrorService {

  Message = new BehaviorSubject<any>({});
  // successMessage = new BehaviorSubject<any>({});
  constructor() {
   }

  alertError(error){
    const message = {type:'danger',message:error.message}   
    this.Message.next(message);
    this.deleteAlert()
  }

  alertAddmessage(data="Add New Data SuccessFul"){
    const message = {type:'success',message:data}    
    this.Message.next(message);
  }
  alertUpdatemessage(data="Update Data SuccessFul"){
    const message = {type:'success',message:data}
    this.Message.next(message);
  }
  alertDeletemessage(data="Delete Data SuccessFul"){
    const message = {type:'success',message:data}
    this.Message.next(message);
  }

  deleteAlert(){
    setTimeout(() => this.Message.next({}), 20000);
  }

}
