import { Injectable } from '@angular/core';

@Injectable()
export class JwtService {

    getToken(): string {
        return window.localStorage['posloginToken'] ? window.localStorage['posloginToken']:false;
    }
    saveToken(token: string) {
        window.localStorage['posloginToken'] = token;
    }

    destroyToken() {
        window.localStorage.removeItem('posloginToken');
        window.localStorage.removeItem('posuserInfo');
    }

    setUser(data:{}){
        window.localStorage['posuserInfo'] = JSON.stringify(data);
    }
    setFeature(data:{}){
        window.localStorage['userFeature'] = JSON.stringify(data);
    }
    getUser(){
        return JSON.parse(window.localStorage['posuserInfo'])
    }

    getFeature():any[]{
        return JSON.parse(window.localStorage['userFeature'])
    }

    checkPermission(asset:string){
        return true;   
    }
}