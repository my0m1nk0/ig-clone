import { Injectable, ErrorHandler } from "@angular/core";
import { HttpClient,HttpHeaders } from "@angular/common/http";
import { JwtService } from "./jwt.service";
import { Router } from "@angular/router";
import { Observable, throwError, BehaviorSubject } from "rxjs";
import { environment } from "../../../environments/environment";
import { map, catchError } from "rxjs/operators";

@Injectable()
export class ServerService {
  // pageLoading = new BehaviorSubject<boolean>(false)
    private errorHandler: ErrorHandler;
    constructor(private http: HttpClient, errorHandler: ErrorHandler, private jwtService: JwtService,private _router: Router) {
        this.errorHandler = errorHandler;
    }

      handleError(error) {
        alert(error.error.message)
        return throwError(error.error);
      }
      get(path: string): Observable<any> {
        // console.log(environment.url);
        
        return this.http.get(`${environment.url}${path}`).pipe(map((res: Response) => {
        
          return res;
        }), catchError(error => {
          console.log(error)
          if( error.statusCode == 403 ){
            this.jwtService.destroyToken()
            this._router.navigate(['/login']);
          }
          return throwError(error.error);
        }))
      }
     
    
      put(path: string, body: Object = {}): Observable<any> {
        //  this.pageLoading.next(true)
        return this.http.put(
          `${environment.url}${path}`,
          JSON.stringify(body)
        ).pipe(map((res: Response) => {
          // this.pageLoading.next(false)
          return res
        }), catchError(this.handleError))
      }
    
      post(path: string, body: Object = {}): Observable<any> {
        //  this.pageLoading.next(true)
        return this.http.post(
          `${environment.url}${path}`,
          JSON.stringify(body)
        ).pipe(map((res: Response) => {
          // this.pageLoading.next(false)
          return res
        }), catchError(this.handleError))
      }
    
      delete(path): Observable<any> {
        //  this.pageLoading.next(true)
       
        return this.http.delete(
          `${environment.url}${path}`
        ).pipe(map((res: Response) => {
          // this.pageLoading.next(false)
          return res
        }), catchError(this.handleError))
      }
    
    
      // getSearch(path: string,data): Observable<any> {
      //   data = JSON.stringify(data.query);
      //   return this.http.get(`${environment.url}${path}&query=${data}`).pipe(map((res: Response) => {
      //     return res;
      //   }), catchError(error => {
      //     return throwError(error.error);
      //   }))
      // }

      async uploadPhoto(data,path){
        let header = new HttpHeaders({"Content-Type":"image/jpeg"})
        return await this.http.put(path,data,{headers:header}).toPromise()
      }

      async getSignUrl():Promise<any>{
        return await this.http.get(`${environment.url}images/upload`).toPromise()
      }

      async awaitGet(path){
        return await this.http.get(environment.url+path).toPromise()
      }
}