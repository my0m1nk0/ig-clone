import { Injectable } from '@angular/core';
import { ServerService } from './server.service';
import { AlertErrorService } from './alert-error.service';

@Injectable()
export class AwsService {

  constructor(private _server:ServerService,private _alert:AlertErrorService) {
       
   }

  async uploadProfie(data){
    // this._server.pageLoading.next(true)
    let fileextinson = data.name.split(".").pop().toLowerCase();
    let validFormats = ['jpg', 'png', 'jpeg', 'gif'];
    let res:any= {image:""}
    if (validFormats.indexOf(fileextinson) == -1) {
      this._alert.alertError({ message: "Please Select Image File" })
      // this._server.pageLoading.next(false)
      return false;
    }else{
        let imgNameRes: any
        let signUrl = await this._server.getSignUrl()
    try{
          imgNameRes = await this._server.uploadPhoto(data,signUrl.url)
          res.image = signUrl.key;
        }catch(e){
          console.log(e)
        }
        
    }
    return res
  }
  
}
