import { Component, OnInit } from "@angular/core";
import { ROUTES } from "./menu-item"
import { JwtService } from '../../shared/services/jwt.service';
import { Router } from '@angular/router';
@Component({
  selector: "app-sidebar",
  templateUrl: "./sidebar.component.html",
  styleUrls: ["./sidebar.component.css"]
})
export class SidebarComponent implements OnInit {
  menuItems: any[];

  constructor(private readonly _jwtService:JwtService,private readonly _router:Router) {}

  ngOnInit() {
    let feature = this._jwtService.getFeature()
    this.menuItems = ROUTES.filter(menuItem => {
      let key = feature.findIndex(x=> x.name == menuItem.tag)
      if(key >= 0)
        return menuItem
    });
  }
  isMobileMenu() {
    if (window.innerWidth > 991) {
      return false;
    }
    return true;
  }

  LogOut(){
    this._jwtService.destroyToken()
    this._router.navigate(['/login']);
  }
}
