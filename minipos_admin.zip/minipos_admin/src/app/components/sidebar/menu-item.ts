
declare interface RouteInfo {
    path: string;
    title: string;
    icon: string;
    class: string;
    tag:string
  }
  
export const ROUTES: RouteInfo[] = [
    {
      path: "/package_configuration",
      title: "Package Configuration",
      icon: "icon-chart-pie-36",
      class: "",
      tag:"Package_Configuration"
    },
    {
      path: "/shop_management",
      title: "Shop Management",
      icon: "icon-chart-pie-36",
      class: "",
      tag:"Shop_Management"
    },

    {
      path: "/shop-license",
      title: "Shop License",
      icon: "icon-chart-pie-36",
      class: "",
      tag:"Shop_License"
    },
  ];